 package grpc.test.office;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.Properties;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

import grpc.test.office.opendoorGrpc.opendoorImplBase;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class AutoDoorsServer extends opendoorImplBase {
	//logger helps in tracing errors by storing info about created methods into a log. Also used to print out logged info.
	private static final Logger logger = Logger.getLogger(AutoDoorsServer.class.getName());

	public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("Starting Server...");
		//creating a new instance of the service to be used 
		AutoDoorsServer doorserver = new AutoDoorsServer();
		
		//to obtain naming properties
		Properties prop = doorserver.getProperties();
		//register the service
		doorserver.registerService(prop);
		
		//Initialising the port to be listened to
		int port = Integer.valueOf( prop.getProperty("service_port") );
	    
		//attempt to create the server...
		try {
			//creating a server builder for the server
			Server server = ServerBuilder.forPort(port)
					//registering the service
			    .addService(doorserver)
			    //finally build
			    .build()
			    //then can call start to begin listening on given port
			    .start();
			
			//to prevent main process from quitting by itself after running in background
			 server.awaitTermination();

		//..and catch to capture possible errors	 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    logger.info("Server started, listening on " + port);	    		    	   
	}
	
	//method to obtain listed properties in .properties file
	private Properties getProperties() {
		Properties prop = null;

		try (InputStream input = new FileInputStream("src/main/resources/autodoors.properties")) {

			prop = new Properties();

			// load a properties file
			prop.load(input);

			// get the property value and print it out
			System.out.println("Automatic Doors Service properties ...");
			System.out.println("\t service_type: " + prop.getProperty("service_type"));
			System.out.println("\t service_name: " + prop.getProperty("service_name"));
			System.out.println("\t service_description: " + prop.getProperty("service_description"));
			System.out.println("\t service_port: " + prop.getProperty("service_port"));

		} catch (IOException ex) {
			ex.printStackTrace();
		}

		return prop;
	}

	//method to register service with listed properties
	private void registerService(Properties prop) {
		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			// Retrieving and storing the property components in variables
			String service_type = prop.getProperty("service_type");
			String service_name = prop.getProperty("service_name");
			int service_port = Integer.valueOf(prop.getProperty("service_port"));
			String service_description_properties = prop.getProperty("service_description");

			// Register a service
			ServiceInfo serviceInfo = ServiceInfo.create(service_type, service_name, service_port,
					service_description_properties);
			jmdns.registerService(serviceInfo);

			System.out.printf("Registering service with type %s and name %s \n", service_type, service_name);

			// Wait a bit
			Thread.sleep(1000);

			// Unregister all services
			// jmdns.unregisterAllServices();

		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
	//this is the overridden server stub for unary service of opendoor
	@Override
	//default async operation on server side
	public void motionDetect(InputRequest request,  StreamObserver<OutputReply> responseObserver) {
		//using variables to store and retrieve requests
		String motion=request.getMotion();
    	int distance= request.getDistance();
    	
		//Initialising OutputReply and building 
		OutputReply.Builder reply = OutputReply.newBuilder();
		
		System.out.println("\nAutomatic sensors have registered...");
		//displays values of motion and distance sent in by client.
		 System.out.println("Motion detected? : " + motion + ", Distance to door : " + distance+ " meters"+ "\n");
		 
	     //gets reply back to client based on met conditions. 		
		 if(motion.equalsIgnoreCase("yes")&& distance <= 5) {
			 //if motion is detected and at a distance of 5 meters or less, the lights switch on and the doors open
			 reply.setLights("Automatic Lights turned on!");
			 reply.setDoors("\nAutomatic doors opened!");
			
	    	}
	    	else if(motion.equalsIgnoreCase("yes")&& distance >5) {
	    		//if the distance is greater than 5 meters but motion has been detected, the lights alone will turn on.
	    		reply.setLights("Automatic Lights turned on!");
	    		reply.setDoors("\nAutomatic doors closed!");

	    	}else {	 
	    		//otherwise, everything stays turned off/closed till either of the conditions above are met.
	    		reply.setLights("Automatic Lights turned off!");
	    		reply.setDoors("\nAutomatic doors closed!");
	    	}
		 
		 //onNext sends one set of data from server to client after another.
		 responseObserver.onNext(reply.build());
	     //onCompleted used to finish the responses.
	     responseObserver.onCompleted();
	}	
}

