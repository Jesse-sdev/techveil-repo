package grpc.test.office;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import grpc.test.office.opendoorGrpc.opendoorBlockingStub;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

//java class to implement automatic door client service 
public class AutoDoorsGUI implements ActionListener {

	private static final Logger logger = Logger.getLogger(AutoDoorsClient.class.getName());

	// declaring variable to store serviceInfo object
	private ServiceInfo autodoorsServiceInfo;

	// variables used in GUi frame and component setup
	JLabel header;
	JLabel header2;
	JLabel motionlabel;
	JLabel distancelabel;
	JFrame frame;
	JPanel panel;
	JButton button;
	static JTextField motionText;
	static JTextField distanceText;
	static JLabel message1;
	static JLabel message2;
	static JTextArea txtarea;

	// implementing GUI properties in constructor
	public AutoDoorsGUI() {

		// calling discovery method
		String autodoors_service_type = "_autodoors._tcp.local.";
		discoverAutoDoorsService(autodoors_service_type);

		frame = new JFrame();

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(40, 40, 10, 40));
		panel.setLayout(new BorderLayout(10,20));

		ImageIcon image = new ImageIcon("C:\\Users\\chigb\\Desktop\\logos.png");
	
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 600, 450);
		frame.setMinimumSize(new Dimension(500, 450));
		frame.setTitle("Automatic Doors Switch");
		frame.setIconImage(image.getImage());
		frame.pack();
		frame.setVisible(true);

		JScrollPane sbar = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.add(sbar);
		frame.setLocationRelativeTo(null);

		header = new JLabel("Welcome To BlueLights! ", JLabel.CENTER);
		header.setBounds(50, 10, 280, 25);
		header.setPreferredSize(new Dimension(280, 80));
		header.setFont(new Font("Serif", Font.ITALIC | Font.ITALIC, 25));
		header.setForeground(Color.BLUE);
		panel.add(header);

		header2 = new JLabel("Turn On for automatic sensor control", JLabel.LEFT);
		header2.setBounds(20, 40, 680, 25);
		header2.setPreferredSize(new Dimension(180, 50));
		header2.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 15));
		header2.setForeground(Color.RED);
		panel.add(header2);

		motionlabel = new JLabel("Motion detected(yes/no): ");
		motionlabel.setBounds(5, 75, 150, 25);
		panel.add(motionlabel);

		motionText = new JTextField();
		motionText.setBounds(280, 75, 150, 25);
		panel.add(motionText);

		distancelabel = new JLabel("Distance(M): ");
		distancelabel.setBounds(5, 150, 150, 25);
		panel.add(distancelabel);

		distanceText = new JTextField();
		distanceText.setBounds(280, 150, 150, 25);
		panel.add(distanceText);

		button = new JButton("Turn ON");
		button.setBounds(5, 215, 100, 25);
		button.addActionListener(this); // calling action performed on the constructor of this class
		panel.add(button);

		message1 = new JLabel("");
		message1.setBounds(10, 235, 1000, 155);
		message1.setFont(new Font("Verdana", Font.BOLD, 15));
		message1.setForeground(Color.BLUE);
		panel.add(message1);
		
		txtarea= new JTextArea(6, 20);
		txtarea.setLineWrap(true);
		txtarea.setWrapStyleWord(true);
		txtarea.setEditable(false);
		txtarea.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 14));	

		JScrollPane scrollPane = new JScrollPane(txtarea);	
		panel.add(scrollPane, BorderLayout.SOUTH);

	}

	// grpc service discovery by naming service
	private void discoverAutoDoorsService(String service_type) {

		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			jmdns.addServiceListener(service_type, new ServiceListener() {

				@Override
				// for resolving service
				public void serviceResolved(ServiceEvent event) {
					System.out.println("Automatic Doors Service resolved: " + event.getInfo());

					autodoorsServiceInfo = event.getInfo();

					int port = autodoorsServiceInfo.getPort();

					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port);
					System.out.println("\t type:" + event.getType());
					System.out.println("\t name: " + event.getName());
					System.out.println("\t description/properties: " + autodoorsServiceInfo.getNiceTextString());
					System.out.println("\t host: " + autodoorsServiceInfo.getHostAddresses()[0]);

				}

				@Override
				// for removing service
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("Automatic Doors Service removed: " + event.getInfo());

				}

				@Override
				// for adding service
				public void serviceAdded(ServiceEvent event) {
					System.out.println("Automatic Doors Service added: " + event.getInfo());

				}

			});

			// Wait a bit
			Thread.sleep(2000);

			jmdns.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	// main method to execute entire program
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// calls the constructor which contains actionable code
					new AutoDoorsGUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// with this method, the main functionality of the client is initialized
	public void actionPerformed(ActionEvent e) {

		String host = "localhost";
		int port = 50056;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing to use blocking stub which blocks code till data is returned from
		// server
		opendoorBlockingStub blockingStub = opendoorGrpc.newBlockingStub(channel);

		// new instance of client class
		AutoDoorsClient client = new AutoDoorsClient();

		// client server creation..
		try {
			//obtaining input from GUI and storing it in variables
			String motion = motionText.getText();
			String distance = distanceText.getText();
			
			// assigning a variable "request" to the building of InputRequest from the client
			InputRequest request = InputRequest.newBuilder().setMotion(motion).setDistance(Integer.parseInt(distance))
					.build();

			// using the stub selected, derive a response from the server based on the
			// request passed in.
			OutputReply response = blockingStub.motionDetect(request);

			// print out with logger. can use system.out.print instead
			logger.info("Response from Server: " + response.getLights() + response.getDoors());

			// print out to GUI
			//message1.setText("Response from Server: " + response.getLights() + ". " + response.getDoors());
			txtarea.append("Response from Server: " + response.getLights() + ". " + response.getDoors() + "\n");
			
			System.out.println("========================================");

			// catch all possible exceptions
		} catch (StatusRuntimeException i) {
			logger.log(Level.WARNING, "RPC failed: {0}", i.getStatus());

			return;

		} finally {
			// shutdown channel
			try {
				channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
			} catch (InterruptedException e1) {

				e1.printStackTrace();
			}
		}
	}

}
