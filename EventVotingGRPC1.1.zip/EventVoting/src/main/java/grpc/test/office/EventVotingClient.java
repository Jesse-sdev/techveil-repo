package grpc.test.office;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

//client creates connection to server, calls server and gives it instructions. Which in return prints it out
public class EventVotingClient {

	private static final Logger logger = Logger.getLogger(EventVotingClient.class.getName());

	private static eventvotingGrpc.eventvotingStub asyncStub;

	public static void main(String[] args) throws Exception {
		String host = "localhost";
		int port = 50054;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing async stub for stream services and blocking for unary

		asyncStub = eventvotingGrpc.newStub(channel);

		// new instance of client class
		EventVotingClient client = new EventVotingClient();

		// calling server-streaming function
		serverStreaming();

		// shutdown channel
		channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);

	}

	// Server streaming for service
	public static void serverStreaming() {

		StreamObserver<ChoiceResult> responseObserver = new StreamObserver<ChoiceResult>() {

			@Override
			public void onNext(ChoiceResult response) {

				System.out.println("Results received: " + response.getResult() + response.getTotal());

			}

			@Override
			public void onError(Throwable t) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onCompleted() {
				// TODO Auto-generated method stub
				System.out.println("......server completed......");
			}

		};

		//
		StreamObserver<ChoiceRequest> requestObserver = asyncStub.teamSelect(responseObserver);

		try {

			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam("team B").setName("Jesse").build());
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam("team B").setName("Adam").build());
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam("team A").setName("Eve").build());

			logger.info(".......SENDING MESSAGES FOR SERVER-STREAMING.......");

			// Mark the end of requests
			requestObserver.onCompleted();

			// Sleep for a bit before sending the next one.
			Thread.sleep(1500);

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (StatusRuntimeException e) {
			logger.log(Level.WARNING, "RPC failed: {0}", e.getStatus());

			return;

		}

	}
}