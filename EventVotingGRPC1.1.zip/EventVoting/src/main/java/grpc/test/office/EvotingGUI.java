package grpc.test.office;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

//java class to implement automatic door client service 
public class EvotingGUI implements ActionListener {

	private static final Logger logger = Logger.getLogger(EventVotingClient.class.getName());
	private static eventvotingGrpc.eventvotingStub asyncStub;

	// declaring variable to store serviceInfo object
	private ServiceInfo evoteServiceInfo;

	// variables used in GUi frame and component setup
	JLabel header;
	JLabel header2;
	JLabel namelabel;
	JLabel namelabel2;
	JLabel namelabel3;
	JLabel teamlabel;
	JLabel teamlabel2;
	JLabel teamlabel3;
	JLabel emplabel;
	JFrame frame;
	JPanel panel;
	JButton button;
	static JButton send;
	static JTextField nameText;
	static JTextField nameText2;
	static JTextField nameText3;
	static JTextField teamText;
	static JTextField teamText2;
	static JTextField teamText3;

	static JTextField empText;
	static JLabel message1;

	// implementing GUI properties in constructor
	public EvotingGUI() {
		
		// calling discovery method
		String evote_service_type = "_evote._tcp.local.";
		discoverEvoteService(evote_service_type);
		
		frame = new JFrame();

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(40, 40, 10, 40));
		panel.setLayout(new BorderLayout(10,20));

		ImageIcon image = new ImageIcon("C:\\Users\\chigb\\Desktop\\logos.png");

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 600, 450);
		frame.setMinimumSize(new Dimension(500, 450));
		frame.setTitle("Event Voting System");
		frame.setIconImage(image.getImage());
		frame.pack();
		frame.setVisible(true);

		JScrollPane sbar = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.add(sbar);
		frame.setLocationRelativeTo(null);

		header = new JLabel("Welcome To BlueLights! ", JLabel.CENTER);
		header.setBounds(50, 10, 280, 25);
		header.setPreferredSize(new Dimension(280, 80));
		header.setFont(new Font("Serif", Font.ITALIC | Font.ITALIC, 25));
		header.setForeground(Color.BLUE);
		panel.add(header);

		header2 = new JLabel("Please indicate your name and vote either Team A or Team B:", JLabel.LEFT);
		header2.setBounds(20, 40, 680, 25);
		header2.setPreferredSize(new Dimension(180, 50));
		header2.setFont(new Font("Verdana", Font.ITALIC, 13));
		header2.setForeground(Color.RED);
		panel.add(header2);

		namelabel = new JLabel("Name: ");
		namelabel.setBounds(5, 75, 100, 25);
		panel.add(namelabel);

		nameText = new JTextField();
		nameText.setBounds(100, 75, 135, 25);
		panel.add(nameText);

		teamlabel = new JLabel("Team: ");
		teamlabel.setBounds(5, 100, 180, 25);
		panel.add(teamlabel);

		teamText = new JTextField();
		teamText.setBounds(100, 100, 135, 25);
	
		panel.add(teamText);

		namelabel2 = new JLabel("Name: ");
		namelabel2.setBounds(5, 130, 100, 25);
		panel.add(namelabel2);

		nameText2 = new JTextField();
		nameText2.setBounds(100, 130, 135, 25);
		panel.add(nameText2);

		teamlabel2 = new JLabel("Team: ");
		teamlabel2.setBounds(5, 155, 180, 25);
		panel.add(teamlabel2);

		teamText2 = new JTextField();
		teamText2.setBounds(100, 155, 135, 25);
		panel.add(teamText2);

		namelabel3 = new JLabel("Name: ");
		namelabel3.setBounds(5, 185, 100, 25);
		panel.add(namelabel3);

		nameText3 = new JTextField();
		nameText3.setBounds(100, 185, 135, 25);
		panel.add(nameText3);

		teamlabel3 = new JLabel("Team: ");
		teamlabel3.setBounds(5, 210, 180, 25);
		panel.add(teamlabel3);

		teamText3 = new JTextField();
		teamText3.setBounds(100, 210, 135, 25);
		panel.add(teamText3);

//		emplabel = new JLabel("Number of voters: ");
//		emplabel.setBounds(5, 125, 180, 25);
//		panel.add(emplabel);
//
//		empText = new JTextField();
//		empText.setBounds(260, 125, 165, 25);
//		panel.add(empText);

		button = new JButton("Get Result");
		button.setBounds(5, 245, 100, 25);
		button.addActionListener(this); // calling action performed on the constructor of this class
		panel.add(button);

//		send = new JButton("Send Vote");
//		send.setBounds(5, 135, 100, 25);
////		send.addActionListener(new ActionListener() {
////			public void actionPerformed(ActionEvent event) {
////				//serverStreaming();
////			}
////		});
//		panel.add(send);

		message1 = new JLabel("");
		message1.setBounds(10, 285, 1000, 55);
		message1.setFont(new Font("Verdana", Font.BOLD, 12));
		message1.setForeground(Color.BLACK);
		panel.add(message1);

//		message2 = new JLabel("");
//		message2.setBounds(10,355,500,55);
//		message2.setFont(new Font("Verdana", Font.BOLD, 12));
//		message2.setForeground(Color.GREEN);
//		panel.add(message2);
//		
//		message3 = new JLabel("");
//		message3.setBounds(10,385,500,55);
//		message3.setFont(new Font("Verdana", Font.BOLD, 12));
//		message3.setForeground(Color.GREEN);
//		panel.add(message3);

		panel.add(message1, BorderLayout.SOUTH);
	}

	// grpc service discovery by naming service
	private void discoverEvoteService(String service_type) {

		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			jmdns.addServiceListener(service_type, new ServiceListener() {

				// for resolving service
				@Override
				public void serviceResolved(ServiceEvent event) {
					System.out.println("Event Voting Service resolved: " + event.getInfo());

					evoteServiceInfo = event.getInfo();

					int port = evoteServiceInfo.getPort();

					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port);
					System.out.println("\t type:" + event.getType());
					System.out.println("\t name: " + event.getName());
					System.out.println("\t description/properties: " + evoteServiceInfo.getNiceTextString());
					System.out.println("\t host: " + evoteServiceInfo.getHostAddresses()[0]);

				}

				// for removing service
				@Override
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("Event Voting Service removed: " + event.getInfo());

				}

				// for adding service
				@Override
				public void serviceAdded(ServiceEvent event) {
					System.out.println("Event Voting Service added: " + event.getInfo());

				}

			});

			// Wait a bit
			Thread.sleep(2000);

			jmdns.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	// main method to execute entire program
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// calls the constructor which contains actionable code
					new EvotingGUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// with this method, the main functionality of the client is initialized
	public void actionPerformed(ActionEvent e) {

		String host = "localhost";
		int port = 50054;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing async stub for stream services and blocking for unary
		asyncStub = eventvotingGrpc.newStub(channel);

		// new instance of client class
		EventVotingClient client = new EventVotingClient();
		
		try {
			// calling server-streaming function
			serverStreaming();
			
		} catch (StatusRuntimeException i) {
			logger.log(Level.WARNING, "RPC failed: {0}", i.getStatus());

			return;

		} finally {
			// shutdown channel
			try {
				channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
			} catch (InterruptedException i) {
				// TODO Auto-generated catch block
				i.printStackTrace();
			}
		}
	}

	// Server streaming for service
	public static void serverStreaming() {

		//obtaining input from GUI and storing it in variables
		String name = nameText.getText();
		String team = teamText.getText();

		String name2 = nameText2.getText();
		String team2 = teamText2.getText();

		String name3 = nameText3.getText();
		String team3 = teamText3.getText();

		StreamObserver<ChoiceResult> responseObserver = new StreamObserver<ChoiceResult>() {

			@Override
			public void onNext(ChoiceResult response) {

				System.out.println("Results received: " + response.getResult() + response.getTotal());

				// to print on GUI
				message1.setText("Results received: " + response.getResult() + response.getTotal());
			}

			@Override
			public void onError(Throwable t) {
				// TODO Auto-generated method stub
				t.getStackTrace();

			}

			@Override
			public void onCompleted() {
				// TODO Auto-generated method stub
				System.out.println("......Event voting server completed......");
				System.out.println("========================================");
			}

		};

		// using the asyncStub, derive a response from the server based on the request passed in.
		StreamObserver<ChoiceRequest> requestObserver = asyncStub.teamSelect(responseObserver);

		try {
			//setting values based on input collected on gui textfield boxes. 
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam(team).setName(name).build());
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam(team2).setName(name2).build());
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam(team3).setName(name3).build());

			logger.info(".......SENDING MESSAGES FOR SERVER-STREAMING.......");

			// Mark the end of requests
			requestObserver.onCompleted();

			// Sleep for a bit before sending the next one.
			Thread.sleep(1500);

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (StatusRuntimeException e) {
			logger.log(Level.WARNING, "RPC failed: {0}", e.getStatus());

			return;

		}

	}
}
