package grpc.test.office;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

//client creates connection to server, calls server and gives it instructions. Which in return prints it out
public class EventVotingClient {

	private static final Logger logger = Logger.getLogger(EventVotingClient.class.getName());

	private static eventvotingGrpc.eventvotingStub asyncStub;

	public static void main(String[] args) throws Exception {
		String host = "localhost";
		int port = 50054;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing async stub for stream services and blocking for unary

		asyncStub = eventvotingGrpc.newStub(channel);

		// new instance of client class
		EventVotingClient client = new EventVotingClient();

		// calling server-streaming function
		clientStreaming();

		// shutdown channel
		channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);

	}

	// Server streaming for service
	public static void clientStreaming() {

		StreamObserver<ChoiceResult> responseObserver = new StreamObserver<ChoiceResult>() {

			@Override
			public void onNext(ChoiceResult response) {

				System.out.println("Results received: " + response.getResult() + response.getTotal());

			}

			@Override
			public void onError(Throwable t) {
				t.printStackTrace();

			}

			@Override
			public void onCompleted() {
				System.out.println("......server completed......");
			}

		};

		//
		StreamObserver<ChoiceRequest> requestObserver = asyncStub.teamSelect(responseObserver);

		try {

			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam("team B").setName("Jesse").build());
			Thread.sleep(500);
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam("team B").setName("Adam").build());
			Thread.sleep(500);
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam("team A").setName("Eve").build());
			Thread.sleep(500);
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam("team A").setName("Matt").build());
			Thread.sleep(500);
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam("team B").setName("Barney").build());
			Thread.sleep(500);
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam("team A").setName("Eintein").build());
			Thread.sleep(500);
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam("team A").setName("Mickey").build());
			Thread.sleep(500);

			logger.info(".......SENDING MESSAGES FOR SERVER-STREAMING.......");

			// Mark the end of requests
			requestObserver.onCompleted();

			// Sleep for a bit before sending the next one.
			Thread.sleep(1500);

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (StatusRuntimeException e) {
			logger.log(Level.WARNING, "RPC failed: {0}", e.getStatus());

			return;

		}

	}
}