package grpc.test.office;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

//java class to implement automatic door client service 
public class EvotingGUI implements ActionListener {

	private static final Logger logger = Logger.getLogger(EventVotingClient.class.getName());
	private static eventvotingGrpc.eventvotingStub asyncStub;

	// declaring variable to store serviceInfo object
	private ServiceInfo evoteServiceInfo;

	// variables used in GUi frame and component setup
	JLabel header;
	JLabel header2;
	JFrame frame;
	JPanel panel;
	JButton button;

	static JLabel message1;
	
	private static ArrayList<String> teamInput= new ArrayList<>();
	private static ArrayList<String> nameInput= new ArrayList<>();
	

	// implementing GUI properties in constructor
	public EvotingGUI() {
		
		// calling discovery method
		String evote_service_type = "_evote._tcp.local.";
		discoverEvoteService(evote_service_type);
		
		frame = new JFrame();

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(40, 40, 10, 40));
		panel.setLayout(new BorderLayout(10,20));

		ImageIcon image = new ImageIcon("C:\\Users\\chigb\\Desktop\\logos.png");

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 600, 450);
		frame.setMinimumSize(new Dimension(500, 450));
		frame.setTitle("Event Voting System");
		frame.setIconImage(image.getImage());
		frame.pack();
		frame.setVisible(true);

		JScrollPane sbar = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.add(sbar);
		frame.setLocationRelativeTo(null);

		header = new JLabel("Welcome To BlueLights! ", JLabel.CENTER);
		header.setBounds(50, 10, 280, 25);
		header.setPreferredSize(new Dimension(280, 80));
		header.setFont(new Font("Serif", Font.ITALIC | Font.ITALIC, 25));
		header.setForeground(Color.BLUE);
		panel.add(header);

		header2 = new JLabel("Please indicate your name and vote either Team A or Team B:", JLabel.LEFT);
		header2.setBounds(20, 40, 680, 25);
		header2.setPreferredSize(new Dimension(180, 50));
		header2.setFont(new Font("Verdana", Font.ITALIC, 13));
		header2.setForeground(Color.RED);
		panel.add(header2);

		button = new JButton("Get Result");
		button.setBounds(25, 265, 150, 45);
		button.addActionListener(this); // calling action performed on the constructor of this class
		panel.add(button, BorderLayout.SOUTH);


		message1 = new JLabel("");
		message1.setBounds(10, 255, 1000, 55);
		message1.setFont(new Font("Verdana", Font.BOLD, 14));
		message1.setForeground(Color.BLACK);
		panel.add(message1);


		panel.add(message1, BorderLayout.SOUTH);
		
		//obtaining input from input dialog box and storing it in variables
		String name = "";
		String team = "";
		String newVotes= "";
		
		 do{
			 name= JOptionPane.showInputDialog(null, "Please enter your first name (e.g. Mickey)");
			 team= JOptionPane.showInputDialog(null, "Please select a team (e.g. Team A)");
			 
			 teamInput.add(team);
			 nameInput.add(name);
			 
			 newVotes= JOptionPane.showInputDialog(null, "Would you like to make another vote? (Yes/ No): ");
			 
		 }while(newVotes.equalsIgnoreCase("yes"));
	}

	// grpc service discovery by naming service
	private void discoverEvoteService(String service_type) {

		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			jmdns.addServiceListener(service_type, new ServiceListener() {

				// for resolving service
				@Override
				public void serviceResolved(ServiceEvent event) {
					System.out.println("Event Voting Service resolved: " + event.getInfo());

					evoteServiceInfo = event.getInfo();

					int port = evoteServiceInfo.getPort();

					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port);
					System.out.println("\t type:" + event.getType());
					System.out.println("\t name: " + event.getName());
					System.out.println("\t description/properties: " + evoteServiceInfo.getNiceTextString());
					System.out.println("\t host: " + evoteServiceInfo.getHostAddresses()[0]);

				}

				// for removing service
				@Override
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("Event Voting Service removed: " + event.getInfo());

				}

				// for adding service
				@Override
				public void serviceAdded(ServiceEvent event) {
					System.out.println("Event Voting Service added: " + event.getInfo());

				}

			});

			// Wait a bit
			Thread.sleep(2000);

			jmdns.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	// main method to execute entire program
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// calls the constructor which contains actionable code
					new EvotingGUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// with this method, the main functionality of the client is initialized
	public void actionPerformed(ActionEvent e) {

		String host = "localhost";
		int port = 50054;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing async stub for stream services and blocking for unary
		asyncStub = eventvotingGrpc.newStub(channel);

		// new instance of client class
		EventVotingClient client = new EventVotingClient();
		
		try {
			// calling server-streaming function
			clientStreaming();
			
		} catch (StatusRuntimeException i) {
			logger.log(Level.WARNING, "RPC failed: {0}", i.getStatus());

			return;

		} finally {
			// shutdown channel
			try {
				channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
			} catch (InterruptedException i) {
				i.printStackTrace();
			}
		}
	}

	// Server streaming for service
	public static void clientStreaming() {

		StreamObserver<ChoiceResult> responseObserver = new StreamObserver<ChoiceResult>() {

			@Override
			public void onNext(ChoiceResult response) {

				System.out.println("Results received: " + response.getResult() + response.getTotal());

				// to print on GUI
				message1.setText("Results received: " + response.getResult() + response.getTotal());
			}

			@Override
			public void onError(Throwable t) {
				t.getStackTrace();

			}

			@Override
			public void onCompleted() {
				System.out.println("......Event voting server completed......");
				System.out.println("========================================");
			}

		};

		// using the asyncStub, derive a response from the server based on the request passed in.
		StreamObserver<ChoiceRequest> requestObserver = asyncStub.teamSelect(responseObserver);

		try {
			//setting values based on input collected on gui textfield boxes. 
			for(int i=0; i< teamInput.size(); i++) {
			requestObserver.onNext(ChoiceRequest.newBuilder().setTeam(teamInput.get(i)).setName(nameInput.get(i)).build());
			}
			
			logger.info(".......SENDING MESSAGES FOR SERVER-STREAMING.......");

			// Mark the end of requests
			requestObserver.onCompleted();

			// Sleep for a bit before sending the next one.
			Thread.sleep(1500);

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (StatusRuntimeException e) {
			logger.log(Level.WARNING, "RPC failed: {0}", e.getStatus());

			return;

		}

	}
}
