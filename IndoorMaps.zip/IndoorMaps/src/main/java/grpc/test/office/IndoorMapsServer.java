
package grpc.test.office;

import java.io.IOException;
import java.util.Random;
import java.util.logging.Logger;

import grpc.test.office.InputRequest;
import grpc.test.office.OutputReply;
import grpc.test.office.indoormapsGrpc.indoormapsImplBase;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class IndoorMapsServer extends indoormapsImplBase {
	// logger helps in tracing errors by storing info about created methods into a
	// log. Also used to print out.
	private static final Logger logger = Logger.getLogger(IndoorMapsServer.class.getName());

	public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("Starting Server...");
		// creating a new instance of the service to be used
		IndoorMapsServer bluebserver = new IndoorMapsServer();
		// initializing the port to be listened to
		int port = 50051;

		// use try to create the server...
		try {
			// creating a server builder for the server
			Server server = ServerBuilder.forPort(port)
					// registering the service
					.addService(bluebserver)
					// finally build
					.build()
					// then you can call start to begin listening on port
					.start();

			// to prevent main process from quiting by itself after running in background
			server.awaitTermination();

			// ..and catch to capture possible errors
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("Server started, listening on " + port);
	}

	// this is the overridden server stub for unary service of selectLocation
	@Override
	// default async operation on server side
	public void selectLocation(InputRequest request, StreamObserver<OutputReply> responseObserver) {
		String room = request.getRoom();
		String occupied = request.getOccupied();

		// to generate random time to assign to rooms
		int timer = 0;
		Random rand = new Random();		
		timer = rand.nextInt(120);
		// System.out.println("this is the timer"+ timer);
		

		// initializing OutputReply and building
		OutputReply.Builder reply = OutputReply.newBuilder();

		System.out.println("Office room selected : " + room + ", Is available? : " + occupied + "\n");
		// gets reply back to client. onNext sends one set of data from server to client
		// after another

		if ((room.equalsIgnoreCase("Conference1") || room.equalsIgnoreCase("Conference2")) && occupied.equals("yes")) {
			reply.setOccupancy("Selected room is occupied!");
			reply.setDuration("\nTime left: " + timer + " minutes");

		} else if ((room.equalsIgnoreCase("Conference1") || room.equalsIgnoreCase("Conference2"))
				&& occupied.equals("no")) {
			reply.setOccupancy("A maximum of 15 persons is allowed in the room at the time!");
			reply.setDuration("\nRoom available for maximum of 120 minutes");

		} else {
			reply.setOccupancy("This room cannot be selected!");
			reply.setDuration("\nNo time allocated for this room!");
		}

		responseObserver.onNext(reply.build());
		// onCompleted used to finish the responses.
		responseObserver.onCompleted();
	}

	// this is the overridden server stub for bidirectional service of streamLocation
	// In this service, I have included another room, "recreation" to one of the available rooms
	@Override
	public StreamObserver<InputRequest> streamLocation(StreamObserver<OutputReply> responseObserver) {
		return new StreamObserver<InputRequest>() {

			@Override
			public void onNext(InputRequest request) {
				String room = request.getRoom();
				String occupied = request.getOccupied();

				// to generate random time to assign to rooms
				int timer = 0;
				Random rand = new Random();
				timer = rand.nextInt(120);

				// initializing OutputReply and building
				OutputReply.Builder reply = OutputReply.newBuilder();

				System.out.println("Office room selected : " + room + ", Is available? : " + occupied + "\n");
				// gets reply back to client. onNext sends one set of data from server to client
				// after another

				if ((room.equalsIgnoreCase("Conference1") || room.equalsIgnoreCase("Conference2")
						|| room.equalsIgnoreCase("recreation")) && occupied.equals("yes")) {
					reply.setOccupancy("Selected room is occupied!");
					reply.setDuration("\nTime left: " + timer + " minutes");

				} else if ((room.equalsIgnoreCase("Conference1") || room.equalsIgnoreCase("Conference2")
						|| room.equalsIgnoreCase("recreation")) && occupied.equals("no")) {
					reply.setOccupancy("A maximum of 15 persons is allowed in the room at the time!");
					reply.setDuration("\nRoom available for maximum of 120 minutes");

				} else {
					reply.setOccupancy("This room cannot be selected!");
					reply.setDuration("\nNo time allocated for this room!");
				}

				responseObserver.onNext(reply.build());

			}

			@Override
			public void onError(Throwable t) {
				// TODO Auto-generated method stubal

			}

			@Override
			public void onCompleted() {
				responseObserver.onCompleted();

			}

		};
	}
}
