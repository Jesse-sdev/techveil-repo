
package grpc.test.office;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

//client creates connection to server, calls server and gives it instructions. Which in return prints it out
public class IndoorMapsClient {

	private static final Logger logger = Logger.getLogger(IndoorMapsClient.class.getName());
	
	private static indoormapsGrpc.indoormapsBlockingStub blockingStub;
	private static indoormapsGrpc.indoormapsStub asyncStub;
	
	private static ServiceInfo mapServiceInfo;
	
	//grpc service discovery by naming service
	private static void discoverMapService(String service_type) {

		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			jmdns.addServiceListener(service_type, new ServiceListener() {

				//to resolve the service 
				@Override
				public void serviceResolved(ServiceEvent event) {
					System.out.println("Maps Service resolved: " + event.getInfo());

					mapServiceInfo = event.getInfo();

					int port = mapServiceInfo.getPort();

					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port);
					System.out.println("\t type:" + event.getType());
					System.out.println("\t name: " + event.getName());
					System.out.println("\t description/properties: " + mapServiceInfo.getNiceTextString());
					System.out.println("\t host: " + mapServiceInfo.getHostAddresses()[0]);

				}

				//to remove the service
				@Override
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("Maps Service removed: " + event.getInfo());

				}

				//to add the service
				@Override
				public void serviceAdded(ServiceEvent event) {
					System.out.println("Maps Service added: " + event.getInfo());

				}

			});

			// Wait a bit
			Thread.sleep(2000);

			jmdns.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	
	
	
	
	public static void main(String[] args) throws Exception {
		String map_service_type = "_maps._tcp.local.";
		discoverMapService(map_service_type);
		
		String host = "localhost";
		int port = 50052;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing async stub for stream services and blocking for unary
		blockingStub = indoormapsGrpc.newBlockingStub(channel);
		asyncStub = indoormapsGrpc.newStub(channel);

		// new instance of client class
		IndoorMapsClient client = new IndoorMapsClient();
		
		//calling Unary function
		unary();
		
		//calling Bi-directional function
		bidirectional();
		
		//shutdown channel
		channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);

	}

	// client server creation for unary rpc..
	//Here we assume conference1 room is not occupied
	public static void unary() {
		try {

			// assigning a variable "request" to the building of HelloRequest from the
			// client
			InputRequest request = InputRequest.newBuilder().setRoom("conference1").setOccupied("no").build();

			// using the stub selected, derive a response from the server based on the
			// request passed in.
			OutputReply response = blockingStub.selectLocation(request);

			// print out with logger. can use system.out.print instead
			logger.info("Response from Server: " + response.getOccupancy() + response.getDuration());

			// catch all possible exceptions
		} catch (StatusRuntimeException e) {
			logger.log(Level.WARNING, "RPC failed: {0}", e.getStatus());

			return;

		}
	}// end unary

	// Bidirection streaming for service
	public static void bidirectional() {

		StreamObserver<OutputReply> responseObserver = new StreamObserver<OutputReply>() {

			@Override
			public void onNext(OutputReply response) {

				System.out.println("Results received: " + response.getOccupancy() + response.getDuration());

			}

			@Override
			public void onError(Throwable t) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onCompleted() {
				// TODO Auto-generated method stub
				System.out.println("......server completed......");
			}

		};

		//
		StreamObserver<InputRequest> requestObserver = asyncStub.streamLocation(responseObserver);
		
		//Here we assume conference1 room is occupied, conference2 room is not occupied and recreation room is occupied
		try {

			requestObserver.onNext(InputRequest.newBuilder().setRoom("conference1").setOccupied("yes").build());
			 requestObserver.onNext(InputRequest.newBuilder().setRoom("conference2").setOccupied("no").build());
			 requestObserver.onNext(InputRequest.newBuilder().setRoom("recreation").setOccupied("yes").build());

			System.out.println(".......SENDING MESSAGES FOR BIDIRECTIONAL.......");

			// Mark the end of requests
			requestObserver.onCompleted();

			// Sleep for a bit before sending the next one.
			Thread.sleep(new Random().nextInt(1000) + 500);

		} catch (RuntimeException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
