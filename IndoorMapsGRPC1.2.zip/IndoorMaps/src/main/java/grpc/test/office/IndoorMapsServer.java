
package grpc.test.office;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

import grpc.test.office.indoormapsGrpc.indoormapsImplBase;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class IndoorMapsServer extends indoormapsImplBase {
	// logger helps in tracing errors by storing info about created methods into a
	// log. Also used to print out.
	private static final Logger logger = Logger.getLogger(IndoorMapsServer.class.getName());

	public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("Starting Server...");
		// creating a new instance of the service to be used
		IndoorMapsServer bluebserver = new IndoorMapsServer();
		
		//to obtain naming properties
		Properties prop= bluebserver.getProperties();
		
		//register the service
		bluebserver.registerService(prop);
		
		// initializing the port to be listened to
		int port = Integer.valueOf( prop.getProperty("service_port"));

		// use try to create the server...
		try {
			// creating a server builder for the server
			Server server = ServerBuilder.forPort(port)
					// registering the service
					.addService(bluebserver)
					// finally build
					.build()
					// then you can call start to begin listening on port
					.start();

			// to prevent main process from quitting by itself after running in background
			server.awaitTermination();

			// ..and catch to capture possible errors
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("Server started, listening on " + port);
	}

	
	//method to obtain listed properties in .properties file
	private Properties getProperties() {
		Properties prop = null;		
		
		 try (InputStream input = new FileInputStream("src/main/resources/maps.properties")) {

	            prop = new Properties();

	            // load a properties file
	            prop.load(input);

	            // get the property value and print it out
	            System.out.println("Indoor Maps Service properties ...");
	            System.out.println("\t service_type: " + prop.getProperty("service_type"));
	            System.out.println("\t service_name: " +prop.getProperty("service_name"));
	            System.out.println("\t service_description: " +prop.getProperty("service_description"));
		        System.out.println("\t service_port: " +prop.getProperty("service_port"));

	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }
	
		 return prop;
	}
	
	//method to register service with listed properties
	private void registerService(Properties prop) {
		 try {
	            // Create a JmDNS instance
	            JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());
	            
	         // Retrieving and storing the property components in variables
	            String service_type = prop.getProperty("service_type") ;
	            String service_name = prop.getProperty("service_name")  ;
	            int service_port = Integer.valueOf( prop.getProperty("service_port"));	            
	            String service_description_properties = prop.getProperty("service_description");
	            
	            // Register service
	            ServiceInfo serviceInfo = ServiceInfo.create(service_type, service_name, service_port, service_description_properties);
	            jmdns.registerService(serviceInfo);
	            
	            System.out.printf("Registering service with type %s and name %s \n", service_type, service_name);
	            
	            // Wait a bit
	            Thread.sleep(1000);

	            // Unregister all services
	            //jmdns.unregisterAllServices();

	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	            
	        } catch (InterruptedException e) {
				e.printStackTrace();
			}
		
	}

	// this is the overridden server stub for unary service of selectLocation
	@Override
	// default async operation on server side
	public void selectLocation(InputRequest request, StreamObserver<OutputReply> responseObserver) {
		//using variables to store and retrieve requests
		String room = request.getRoom();
		String occupied = request.getOccupied();

		// to generate random time to assign to rooms
		int timer = 0;
		Random rand = new Random();		
		timer = rand.nextInt(120);
		// System.out.println("this is the timer"+ timer);
		

		// initializing OutputReply and building
		OutputReply.Builder reply = OutputReply.newBuilder();

		System.out.println("Office room selected : " + room + ", Is occupied? : " + occupied + "\n");
		
		if ((room.equalsIgnoreCase("Conference1") || room.equalsIgnoreCase("Conference2")) && occupied.equals("yes")) {
			reply.setOccupancy("Selected room is occupied!");
			reply.setDuration("\nTime left: " + timer + " minutes");

		} else if ((room.equalsIgnoreCase("Conference1") || room.equalsIgnoreCase("Conference2"))
				&& occupied.equals("no")) {
			reply.setOccupancy("A maximum of 15 persons is allowed in the room at the time!");
			reply.setDuration("\nRoom available for maximum of 120 minutes");

		} else {
			reply.setOccupancy("This room cannot be selected!");
			reply.setDuration("\nNo time allocated for this room!");
		}
		
		// gets reply back to client. onNext sends one set of data from server to client after another
		responseObserver.onNext(reply.build());
		
		// onCompleted used to finish the responses.
		responseObserver.onCompleted();
	}

	// this is the overridden server stub for bidirectional service of streamLocation
	// In this service, I have included another room, "recreation" to mark the different results from unary service
	@Override
	public StreamObserver<InputRequest> streamLocation(StreamObserver<OutputReply> responseObserver) {
		return new StreamObserver<InputRequest>() {

			@Override
			public void onNext(InputRequest request) {
				String room = request.getRoom();
				String occupied = request.getOccupied();

				// to generate random time to assign to rooms
				int timer = 0;
				Random rand = new Random();
				timer = rand.nextInt(120);

				// initializing OutputReply and building
				OutputReply.Builder reply = OutputReply.newBuilder();

				System.out.println("Office room selected : " + room + ", Is occupied? : " + occupied + "\n");			

				if ((room.equalsIgnoreCase("Conference1") || room.equalsIgnoreCase("Conference2")
						|| room.equalsIgnoreCase("recreation")) && occupied.equals("yes")) {
					reply.setOccupancy("Selected room is occupied!");
					reply.setDuration("\nTime left: " + timer + " minutes");

				} else if ((room.equalsIgnoreCase("Conference1") || room.equalsIgnoreCase("Conference2")
						|| room.equalsIgnoreCase("recreation")) && occupied.equals("no")) {
					reply.setOccupancy("A maximum of 15 persons is allowed in the room at the time!");
					reply.setDuration("\nRoom available for maximum of 120 minutes");

				} else {
					reply.setOccupancy("This room: "+room+", cannot be selected!");
					reply.setDuration("\nNo time allocated for this room!");
				}

				// gets reply back to client. onNext sends one set of data from server to client
				// after another
				responseObserver.onNext(reply.build());

			}

			@Override
			public void onError(Throwable t) {
				t.printStackTrace();

			}

			@Override
			public void onCompleted() {
				System.out.println("========================================");
				responseObserver.onCompleted();

			}

		};
	}
}
