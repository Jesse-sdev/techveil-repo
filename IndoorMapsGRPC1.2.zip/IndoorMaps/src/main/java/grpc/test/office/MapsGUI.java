package grpc.test.office;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

//java class to implement automatic door client service 
public class MapsGUI implements ActionListener {

	private static final Logger logger = Logger.getLogger(IndoorMapsClient.class.getName());
	private static indoormapsGrpc.indoormapsBlockingStub blockingStub;
	private static indoormapsGrpc.indoormapsStub asyncStub;

	// declaring variable to store serviceinfo object
	private ServiceInfo mapServiceInfo;

	// variables used in GUi frame and component setup
	JLabel header;
	JLabel header2;
	JLabel roomlabel;
	JLabel occupiedlabel;
	JFrame frame;
	JPanel panel;
	JButton button;
	static JTextField roomText;
	static JTextField roomText2;
	static JTextField roomText3;
	static JTextField occupiedText;
	static JTextField occupiedText2;
	static JTextField occupiedText3;
	static JLabel message1;
	static JLabel message2;
	static JLabel message3;

	static JTextArea txtarea;

	// implementing GUI properties in constructor
	public MapsGUI() {

		// calling discovery method
		String map_service_type = "_maps._tcp.local.";
		discoverMapService(map_service_type);

		frame = new JFrame();

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(40, 40, 10, 40));
		panel.setLayout(new BorderLayout(20, 40));

		ImageIcon image = new ImageIcon("C:\\Users\\chigb\\Desktop\\logos.png");

		// frame.add(panel, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 800, 650);
		frame.setMinimumSize(new Dimension(500, 650));
		frame.setTitle("Indoor Maps");
		frame.setIconImage(image.getImage());
		frame.pack();
		frame.setVisible(true);

		JScrollPane sbar = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.add(sbar);
		frame.setLocationRelativeTo(null);

		header = new JLabel("Welcome To BlueLights! ", JLabel.CENTER);
		header.setBounds(50, 10, 280, 25);
		header.setPreferredSize(new Dimension(280, 80));
		header.setFont(new Font("Serif", Font.ITALIC | Font.ITALIC, 25));
		header.setForeground(Color.BLUE);
		panel.add(header);

		header2 = new JLabel("Please select a ROOM to check status", JLabel.LEFT);
		header2.setBounds(20, 40, 680, 25);
		header2.setPreferredSize(new Dimension(180, 50));
		header2.setFont(new Font("Verdana", Font.BOLD, 15));
		header2.setForeground(Color.RED);
		panel.add(header2);

		JLabel header3 = new JLabel("(Conference1/ Conference2/recreation):", JLabel.LEFT);
		header3.setBounds(20, 60, 680, 25);
		header3.setPreferredSize(new Dimension(180, 50));
		header3.setFont(new Font("Verdana", Font.ITALIC, 13));
		header3.setForeground(Color.RED);
		panel.add(header3);

		roomlabel = new JLabel("ROOM: ");
		roomlabel.setBounds(5, 95, 100, 25);
		panel.add(roomlabel);

		roomText = new JTextField();
		roomText.setBounds(260, 95, 165, 25);
		panel.add(roomText);

		occupiedlabel = new JLabel("OCCUPIED? (Yes or No): ");
		occupiedlabel.setBounds(5, 125, 180, 25);
		panel.add(occupiedlabel);

		occupiedText = new JTextField();
		occupiedText.setBounds(260, 125, 165, 25);
		panel.add(occupiedText);

		roomlabel = new JLabel("ROOM: ");
		roomlabel.setBounds(5, 175, 100, 25);
		panel.add(roomlabel);

		roomText2 = new JTextField();
		roomText2.setBounds(260, 175, 165, 25);
		panel.add(roomText2);

		occupiedlabel = new JLabel("OCCUPIED? (Yes or No): ");
		occupiedlabel.setBounds(5, 205, 180, 25);
		panel.add(occupiedlabel);

		occupiedText2 = new JTextField();
		occupiedText2.setBounds(260, 205, 165, 25);
		panel.add(occupiedText2);

		roomlabel = new JLabel("ROOM: ");
		roomlabel.setBounds(5, 255, 100, 25);
		panel.add(roomlabel);

		roomText3 = new JTextField();
		roomText3.setBounds(260, 255, 165, 25);
		panel.add(roomText3);

		occupiedlabel = new JLabel("OCCUPIED? (Yes or No): ");
		occupiedlabel.setBounds(5, 285, 180, 25);
		panel.add(occupiedlabel);

		occupiedText3 = new JTextField();
		occupiedText3.setBounds(260, 285, 165, 25);
		panel.add(occupiedText3);

		button = new JButton("Request");
		button.setBounds(5, 335, 100, 25);
		button.addActionListener(this); // calling action performed on the constructor of this class
		panel.add(button);

		message1 = new JLabel("");
		message1.setBounds(10, 355, 1000, 55);
		panel.add(message1);

		message2 = new JLabel("");
		message2.setBounds(10, 385, 500, 55);
		panel.add(message2);

		message3 = new JLabel("");
		message3.setBounds(10, 415, 500, 55);
		panel.add(message3);

		txtarea = new JTextArea(10, 30);
		txtarea.setLineWrap(true);
		txtarea.setWrapStyleWord(true);
		txtarea.setEditable(false);
		txtarea.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 14));

		JScrollPane scrollPane = new JScrollPane(txtarea);
		panel.add(scrollPane, BorderLayout.SOUTH);
	}

	// grpc service discovery by naming service
	private void discoverMapService(String service_type) {

		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			jmdns.addServiceListener(service_type, new ServiceListener() {

				// for resolving service
				@Override
				public void serviceResolved(ServiceEvent event) {
					System.out.println("Maps Service resolved: " + event.getInfo());

					mapServiceInfo = event.getInfo();

					int port = mapServiceInfo.getPort();

					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port);
					System.out.println("\t type:" + event.getType());
					System.out.println("\t name: " + event.getName());
					System.out.println("\t description/properties: " + mapServiceInfo.getNiceTextString());
					System.out.println("\t host: " + mapServiceInfo.getHostAddresses()[0]);

				}

				// for removing service
				@Override
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("Maps Service removed: " + event.getInfo());

				}

				// for adding service
				@Override
				public void serviceAdded(ServiceEvent event) {
					System.out.println("Maps Service added: " + event.getInfo());

				}

			});

			// Wait a bit
			Thread.sleep(2000);

			jmdns.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	// main method to execute entire program
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// calls the constructor which contains actionable code
					new MapsGUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// with this method, the main functionality of the client as well ass the naming
	// service is initialized
	public void actionPerformed(ActionEvent e) {

		String host = "localhost";
		int port = 50052;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing async stub for stream services and blocking for unary
		blockingStub = indoormapsGrpc.newBlockingStub(channel);
		asyncStub = indoormapsGrpc.newStub(channel);

		// new instance of client class
		IndoorMapsClient client = new IndoorMapsClient();

		// to determine what kind of service to call based on user input
		if (roomText2.getText().equals("") && roomText3.getText().equals("")) {
			// calling Unary function
			unary();
		} else {
			// calling Bi-directional function
			bidirectional();
		}

		// shutdown channel
		try {
			channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
		} catch (InterruptedException i) {

			i.printStackTrace();
		}
	}

	// client server creation for unary rpc..
	// Here we assume conference1 room is not occupied
	public static void unary() {
		String room = roomText.getText();
		String vacancy = occupiedText.getText();
		try {

			// assigning a variable "request" to the building of HelloRequest from the
			// client
			InputRequest request = InputRequest.newBuilder().setRoom(room).setOccupied(vacancy).build();

			// using the stub selected, derive a response from the server based on the
			// request passed in.
			OutputReply response = blockingStub.selectLocation(request);

			// print out to terminal client with logger. can use system.out.print instead
			logger.info("Response from Server: " + response.getOccupancy() + response.getDuration());

			// print out to GUI client
			txtarea.append("Response from Server: " + response.getOccupancy() + "\n" + response.getDuration() + "\n");

			// catch all possible exceptions
		} catch (StatusRuntimeException e) {
			logger.log(Level.WARNING, "RPC failed: {0}", e.getStatus());
			return;
		}

	}// end unary

	// Bi-direction streaming for service
	public static void bidirectional() {
		
		String room = roomText.getText();
		String room2 = roomText2.getText();
		String room3 = roomText3.getText();
		String vacancy = occupiedText.getText();
		String vacancy2 = occupiedText2.getText();
		String vacancy3 = occupiedText3.getText();

		StreamObserver<OutputReply> responseObserver = new StreamObserver<OutputReply>() {
			int counter = 1;// to determine number gui print outs

			@Override
			public void onNext(OutputReply response) {
				// print out to terminal client
				System.out.println(
						"Results received " + counter + " : " + response.getOccupancy() + response.getDuration());

				// print out to GUI client
				txtarea.append("Results received " + counter + " : " + response.getOccupancy() + response.getDuration()
						+ "\n");
				counter++;
			}

			@Override
			public void onError(Throwable t) {
				// TODO Auto-generated method stub
			}

			@Override
			public void onCompleted() {
				// TODO Auto-generated method stub
				System.out.println("......server completed......");
			}
		};

		//
		StreamObserver<InputRequest> requestObserver = asyncStub.streamLocation(responseObserver);

		// Here we assume conference1 room is occupied, conference2 room is not occupied
		// and recreation room is occupied
		try {

			requestObserver.onNext(InputRequest.newBuilder().setRoom(room).setOccupied(vacancy).build());
			requestObserver.onNext(InputRequest.newBuilder().setRoom(room2).setOccupied(vacancy2).build());
			requestObserver.onNext(InputRequest.newBuilder().setRoom(room3).setOccupied(vacancy3).build());

			System.out.println(".......SENDING MESSAGES FOR BIDIRECTIONAL.......");

			// Mark the end of requests
			requestObserver.onCompleted();

			// Sleep for a bit before sending the next one.
			Thread.sleep(new Random().nextInt(1000) + 500);
		} catch (RuntimeException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
