package grpc.test.office;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 * The Indoor Maps(Maps) service is used to view one or more locations in the office building at a time and determine its availabity and capacity.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: IndoorMaps.proto")
public final class indoormapsGrpc {

  private indoormapsGrpc() {}

  public static final String SERVICE_NAME = "office.indoormaps";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<grpc.test.office.InputRequest,
      grpc.test.office.OutputReply> getSelectLocationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SelectLocation",
      requestType = grpc.test.office.InputRequest.class,
      responseType = grpc.test.office.OutputReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.test.office.InputRequest,
      grpc.test.office.OutputReply> getSelectLocationMethod() {
    io.grpc.MethodDescriptor<grpc.test.office.InputRequest, grpc.test.office.OutputReply> getSelectLocationMethod;
    if ((getSelectLocationMethod = indoormapsGrpc.getSelectLocationMethod) == null) {
      synchronized (indoormapsGrpc.class) {
        if ((getSelectLocationMethod = indoormapsGrpc.getSelectLocationMethod) == null) {
          indoormapsGrpc.getSelectLocationMethod = getSelectLocationMethod = 
              io.grpc.MethodDescriptor.<grpc.test.office.InputRequest, grpc.test.office.OutputReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "office.indoormaps", "SelectLocation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.test.office.InputRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.test.office.OutputReply.getDefaultInstance()))
                  .setSchemaDescriptor(new indoormapsMethodDescriptorSupplier("SelectLocation"))
                  .build();
          }
        }
     }
     return getSelectLocationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.test.office.InputRequest,
      grpc.test.office.OutputReply> getStreamLocationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamLocation",
      requestType = grpc.test.office.InputRequest.class,
      responseType = grpc.test.office.OutputReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
  public static io.grpc.MethodDescriptor<grpc.test.office.InputRequest,
      grpc.test.office.OutputReply> getStreamLocationMethod() {
    io.grpc.MethodDescriptor<grpc.test.office.InputRequest, grpc.test.office.OutputReply> getStreamLocationMethod;
    if ((getStreamLocationMethod = indoormapsGrpc.getStreamLocationMethod) == null) {
      synchronized (indoormapsGrpc.class) {
        if ((getStreamLocationMethod = indoormapsGrpc.getStreamLocationMethod) == null) {
          indoormapsGrpc.getStreamLocationMethod = getStreamLocationMethod = 
              io.grpc.MethodDescriptor.<grpc.test.office.InputRequest, grpc.test.office.OutputReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "office.indoormaps", "StreamLocation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.test.office.InputRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.test.office.OutputReply.getDefaultInstance()))
                  .setSchemaDescriptor(new indoormapsMethodDescriptorSupplier("StreamLocation"))
                  .build();
          }
        }
     }
     return getStreamLocationMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static indoormapsStub newStub(io.grpc.Channel channel) {
    return new indoormapsStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static indoormapsBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new indoormapsBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static indoormapsFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new indoormapsFutureStub(channel);
  }

  /**
   * <pre>
   * The Indoor Maps(Maps) service is used to view one or more locations in the office building at a time and determine its availabity and capacity.
   * </pre>
   */
  public static abstract class indoormapsImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Provides both unary for single request and bidirectional for multiple requests
     * </pre>
     */
    public void selectLocation(grpc.test.office.InputRequest request,
        io.grpc.stub.StreamObserver<grpc.test.office.OutputReply> responseObserver) {
      asyncUnimplementedUnaryCall(getSelectLocationMethod(), responseObserver);
    }

    /**
     */
    public io.grpc.stub.StreamObserver<grpc.test.office.InputRequest> streamLocation(
        io.grpc.stub.StreamObserver<grpc.test.office.OutputReply> responseObserver) {
      return asyncUnimplementedStreamingCall(getStreamLocationMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getSelectLocationMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.test.office.InputRequest,
                grpc.test.office.OutputReply>(
                  this, METHODID_SELECT_LOCATION)))
          .addMethod(
            getStreamLocationMethod(),
            asyncBidiStreamingCall(
              new MethodHandlers<
                grpc.test.office.InputRequest,
                grpc.test.office.OutputReply>(
                  this, METHODID_STREAM_LOCATION)))
          .build();
    }
  }

  /**
   * <pre>
   * The Indoor Maps(Maps) service is used to view one or more locations in the office building at a time and determine its availabity and capacity.
   * </pre>
   */
  public static final class indoormapsStub extends io.grpc.stub.AbstractStub<indoormapsStub> {
    private indoormapsStub(io.grpc.Channel channel) {
      super(channel);
    }

    private indoormapsStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected indoormapsStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new indoormapsStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provides both unary for single request and bidirectional for multiple requests
     * </pre>
     */
    public void selectLocation(grpc.test.office.InputRequest request,
        io.grpc.stub.StreamObserver<grpc.test.office.OutputReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getSelectLocationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public io.grpc.stub.StreamObserver<grpc.test.office.InputRequest> streamLocation(
        io.grpc.stub.StreamObserver<grpc.test.office.OutputReply> responseObserver) {
      return asyncBidiStreamingCall(
          getChannel().newCall(getStreamLocationMethod(), getCallOptions()), responseObserver);
    }
  }

  /**
   * <pre>
   * The Indoor Maps(Maps) service is used to view one or more locations in the office building at a time and determine its availabity and capacity.
   * </pre>
   */
  public static final class indoormapsBlockingStub extends io.grpc.stub.AbstractStub<indoormapsBlockingStub> {
    private indoormapsBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private indoormapsBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected indoormapsBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new indoormapsBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provides both unary for single request and bidirectional for multiple requests
     * </pre>
     */
    public grpc.test.office.OutputReply selectLocation(grpc.test.office.InputRequest request) {
      return blockingUnaryCall(
          getChannel(), getSelectLocationMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * The Indoor Maps(Maps) service is used to view one or more locations in the office building at a time and determine its availabity and capacity.
   * </pre>
   */
  public static final class indoormapsFutureStub extends io.grpc.stub.AbstractStub<indoormapsFutureStub> {
    private indoormapsFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private indoormapsFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected indoormapsFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new indoormapsFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provides both unary for single request and bidirectional for multiple requests
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.test.office.OutputReply> selectLocation(
        grpc.test.office.InputRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getSelectLocationMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_SELECT_LOCATION = 0;
  private static final int METHODID_STREAM_LOCATION = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final indoormapsImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(indoormapsImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_SELECT_LOCATION:
          serviceImpl.selectLocation((grpc.test.office.InputRequest) request,
              (io.grpc.stub.StreamObserver<grpc.test.office.OutputReply>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_STREAM_LOCATION:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.streamLocation(
              (io.grpc.stub.StreamObserver<grpc.test.office.OutputReply>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class indoormapsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    indoormapsBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return grpc.test.office.OfficeServiceImpl.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("indoormaps");
    }
  }

  private static final class indoormapsFileDescriptorSupplier
      extends indoormapsBaseDescriptorSupplier {
    indoormapsFileDescriptorSupplier() {}
  }

  private static final class indoormapsMethodDescriptorSupplier
      extends indoormapsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    indoormapsMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (indoormapsGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new indoormapsFileDescriptorSupplier())
              .addMethod(getSelectLocationMethod())
              .addMethod(getStreamLocationMethod())
              .build();
        }
      }
    }
    return result;
  }
}
