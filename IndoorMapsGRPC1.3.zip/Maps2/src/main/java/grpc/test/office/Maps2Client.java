
package grpc.test.office;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;

import grpc.test.office.InputRequest.Selection;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

//client creates connection to server, calls server and gives it instructions. Which in return prints it out
public class Maps2Client {

	private static final Logger logger = Logger.getLogger(Maps2Client.class.getName());
	
	private static indoormapsGrpc.indoormapsBlockingStub blockingStub;
	private static indoormapsGrpc.indoormapsStub asyncStub;
	
	private static ServiceInfo map2ServiceInfo;
	
	//grpc service discovery by naming service
	private static void discoverMapService(String service_type) {

		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			jmdns.addServiceListener(service_type, new ServiceListener() {

				//to resolve the service 
				@Override
				public void serviceResolved(ServiceEvent event) {
					System.out.println("Maps Service resolved: " + event.getInfo());

					map2ServiceInfo = event.getInfo();

					int port = map2ServiceInfo.getPort();

					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port);
					System.out.println("\t type:" + event.getType());
					System.out.println("\t name: " + event.getName());
					System.out.println("\t description/properties: " + map2ServiceInfo.getNiceTextString());
					System.out.println("\t host: " + map2ServiceInfo.getHostAddresses()[0]);

				}

				//to remove the service
				@Override
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("Maps Service removed: " + event.getInfo());

				}

				//to add the service
				@Override
				public void serviceAdded(ServiceEvent event) {
					System.out.println("Maps Service added: " + event.getInfo());

				}

			});

			// Wait a bit
			Thread.sleep(2000);

			jmdns.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	
	
	
	
	public static void main(String[] args) throws Exception {
		String map_service_type = "_maps2._tcp.local.";
		discoverMapService(map_service_type);
		
		String host = "localhost";
		int port = 50052;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing async stub for stream services and blocking for unary
		blockingStub = indoormapsGrpc.newBlockingStub(channel);
		asyncStub = indoormapsGrpc.newStub(channel);

		// new instance of client class
		Maps2Client client = new Maps2Client();
			
		//calling Bi-directional function
		bidirectional();
		
		//shutdown channel
		channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);

	}



	// Bidirection streaming for service
	public static void bidirectional() {

		StreamObserver<OutputReply> responseObserver = new StreamObserver<OutputReply>() {

			@Override
			public void onNext(OutputReply response) {

				System.out.println("Results received: " + response.getOccupancy() + response.getDuration());

			}

			@Override
			public void onError(Throwable t) {
				t.printStackTrace();

			}

			@Override
			public void onCompleted() {
				System.out.println("......server completed......");
			}

		};

		//
		StreamObserver<InputRequest> requestObserver = asyncStub.streamLocation(responseObserver);
		
		//Here we assume conference1 room is occupied, conference2 room is not occupied and recreation room is occupied
		try {

			requestObserver.onNext(InputRequest.newBuilder().setOccupied("yes").setSelection(Selection.forNumber(1)).build());
			 requestObserver.onNext(InputRequest.newBuilder().setOccupied("no").setSelection(Selection.forNumber(2)).build());
			 requestObserver.onNext(InputRequest.newBuilder().setOccupied("yes").setSelection(Selection.forNumber(3)).build());

			System.out.println(".......SENDING MESSAGES FOR BIDIRECTIONAL.......");

			// Mark the end of requests
			requestObserver.onCompleted();

			// Sleep for a bit before sending the next one.
			Thread.sleep(new Random().nextInt(1000) + 500);

		} catch (RuntimeException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}

