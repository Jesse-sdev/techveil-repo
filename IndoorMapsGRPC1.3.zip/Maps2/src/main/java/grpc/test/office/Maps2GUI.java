package grpc.test.office;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import grpc.test.office.InputRequest.Selection;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

//java class to implement automatic door client service 
public class Maps2GUI implements ActionListener {

	private static final Logger logger = Logger.getLogger(Maps2Client.class.getName());
	private static indoormapsGrpc.indoormapsBlockingStub blockingStub;
	private static indoormapsGrpc.indoormapsStub asyncStub;

	// declaring variable to store serviceinfo object
	private ServiceInfo map2ServiceInfo;

	// variables used in GUi frame and component setup
	JLabel header;
	JLabel header2;
	JLabel roomlabel;
	JLabel occupiedlabel;
	JFrame frame;
	JPanel panel;
	JButton button;
	static JComboBox comboSelection;
	static JComboBox comboSelection2;
	static JComboBox comboSelection3;
	static JLabel message1;
	static JLabel message2;
	static JLabel message3;

	static JTextArea txtarea;

	// implementing GUI properties in constructor
	public Maps2GUI() {

		// calling discovery method
		String map_service_type = "_maps2._tcp.local.";
		discoverMapService(map_service_type);

		frame = new JFrame();

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(40, 40, 10, 40));
		panel.setLayout(new BorderLayout(20, 40));

		ImageIcon image = new ImageIcon("C:\\Users\\chigb\\Desktop\\logos.png");

		// frame.add(panel, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 800, 650);
		frame.setMinimumSize(new Dimension(500, 650));
		frame.setTitle("Indoor Maps");
		frame.setIconImage(image.getImage());
		frame.pack();
		frame.setVisible(true);

		JScrollPane sbar = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.add(sbar);
		frame.setLocationRelativeTo(null);

		header = new JLabel("Welcome To BlueLights! ", JLabel.CENTER);
		header.setBounds(50, 10, 280, 25);
		header.setPreferredSize(new Dimension(280, 80));
		header.setFont(new Font("Serif", Font.ITALIC | Font.ITALIC, 25));
		header.setForeground(Color.BLUE);
		panel.add(header);

		header2 = new JLabel("Please select a ROOM to check status", JLabel.LEFT);
		header2.setBounds(20, 40, 680, 25);
		header2.setPreferredSize(new Dimension(180, 50));
		header2.setFont(new Font("Verdana", Font.BOLD, 15));
		header2.setForeground(Color.RED);
		panel.add(header2);

		JLabel header3 = new JLabel("(Conference1/ Conference2/recreation):", JLabel.LEFT);
		header3.setBounds(20, 60, 680, 25);
		header3.setPreferredSize(new Dimension(180, 50));
		header3.setFont(new Font("Verdana", Font.ITALIC, 13));
		header3.setForeground(Color.RED);
		panel.add(header3);

		roomlabel = new JLabel("ROOM: ");
		roomlabel.setBounds(5, 95, 100, 25);
		panel.add(roomlabel);

		comboSelection = new JComboBox();
		comboSelection
				.setModel(new DefaultComboBoxModel(new String[] { "", "CONFERENCE 1", "CONFERENCE 2", "RECREATION" }));
		comboSelection.setBounds(260, 95, 165, 25);
		panel.add(comboSelection);

		comboSelection2 = new JComboBox();
		comboSelection2
				.setModel(new DefaultComboBoxModel(new String[] { "", "CONFERENCE 1", "CONFERENCE 2", "RECREATION" }));
		comboSelection2.setBounds(260, 135, 165, 25);
		panel.add(comboSelection2);

		comboSelection3 = new JComboBox();
		comboSelection3
				.setModel(new DefaultComboBoxModel(new String[] { "", "CONFERENCE 1", "CONFERENCE 2", "RECREATION" }));
		comboSelection3.setBounds(260, 175, 165, 25);
		panel.add(comboSelection3);

		button = new JButton("Request");
		button.setBounds(5, 335, 100, 25);
		button.addActionListener(this); // calling action performed on the constructor of this class
		panel.add(button);
		panel.add(button, BorderLayout.SOUTH);

		txtarea = new JTextArea(10, 30);
		txtarea.setLineWrap(true);
		txtarea.setWrapStyleWord(true);
		txtarea.setEditable(false);
		txtarea.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 14));

		JScrollPane scrollPane = new JScrollPane(txtarea);
		panel.add(scrollPane, BorderLayout.SOUTH);
	}

	// grpc service discovery by naming service
	private void discoverMapService(String service_type) {

		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			jmdns.addServiceListener(service_type, new ServiceListener() {

				// for resolving service
				@Override
				public void serviceResolved(ServiceEvent event) {
					System.out.println("Maps Service resolved: " + event.getInfo());

					map2ServiceInfo = event.getInfo();

					int port = map2ServiceInfo.getPort();

					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port);
					System.out.println("\t type:" + event.getType());
					System.out.println("\t name: " + event.getName());
					System.out.println("\t description/properties: " + map2ServiceInfo.getNiceTextString());
					System.out.println("\t host: " + map2ServiceInfo.getHostAddresses()[0]);

				}

				// for removing service
				@Override
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("Maps Service removed: " + event.getInfo());

				}

				// for adding service
				@Override
				public void serviceAdded(ServiceEvent event) {
					System.out.println("Maps Service added: " + event.getInfo());

				}

			});

			// Wait a bit
			Thread.sleep(2000);

			jmdns.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	// main method to execute entire program
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// calls the constructor which contains actionable code
					new Maps2GUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// with this method, the main functionality of the client as well ass the naming
	// service is initialized
	public void actionPerformed(ActionEvent e) {

		String host = "localhost";
		int port = 50052;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing async stub for stream services and blocking for unary
		blockingStub = indoormapsGrpc.newBlockingStub(channel);
		asyncStub = indoormapsGrpc.newStub(channel);

		// new instance of client class
		Maps2Client client = new Maps2Client();

		// calling Bi-directional function
		bidirectional();

		// shutdown channel
		try {
			channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
		} catch (InterruptedException i) {

			i.printStackTrace();
		}
	}

	// Bi-direction streaming for service
	public static void bidirectional() {

		StreamObserver<OutputReply> responseObserver = new StreamObserver<OutputReply>() {
			int counter = 1;// to determine number gui print outs

			@Override
			public void onNext(OutputReply response) {
				// print out to terminal client
				System.out.println(
						"Results received " + counter + " : " + response.getOccupancy() + response.getDuration());

				// print out to GUI client
				txtarea.append("Results received " + counter + " : " + response.getOccupancy() + response.getDuration()
						+ "\n");
				counter++;
			}

			@Override
			public void onError(Throwable t) {
				t.printStackTrace();
			}

			@Override
			public void onCompleted() {
				System.out.println("......server completed......");
			}
		};

		//using async stub
		StreamObserver<InputRequest> requestObserver = asyncStub.streamLocation(responseObserver);

		// a drop down option is used to select one of three location choices
		// the index value as corresponding to proto file is used to make the selection
		// and sends to server
		try {
			int index = comboSelection.getSelectedIndex();
			Selection selection = Selection.forNumber(index);

			int index2 = comboSelection2.getSelectedIndex();
			Selection selection2 = Selection.forNumber(index2);

			int index3 = comboSelection3.getSelectedIndex();
			Selection selection3 = Selection.forNumber(index3);

			// the random values simulate automatic response to the vacancy of any room
			// with the two options based on random selection, the room can be determined
			// vacant or occupied
			int rand = (int) Math.floor(Math.random() * (24 - 3 + 1) + 3);
			String vacancy = "";
			String vacancy2 = "";
			if (rand % 2 == 1) {
				vacancy = "yes";
				vacancy2 = "no";
			} else {
				vacancy = "no";
				vacancy2 = "yes";

			}

			// the three requests are then stored and built using the next method to send
			// request one after the other
			requestObserver.onNext(InputRequest.newBuilder().setSelection(selection).setOccupied(vacancy).build());
			requestObserver.onNext(InputRequest.newBuilder().setSelection(selection2).setOccupied(vacancy).build());
			requestObserver.onNext(InputRequest.newBuilder().setSelection(selection3).setOccupied(vacancy2).build());

			System.out.println(".......SENDING MESSAGES FOR BIDIRECTIONAL.......");

			// Mark the end of requests
			requestObserver.onCompleted();

			// Sleep for a bit before sending the next one.
			Thread.sleep(new Random().nextInt(1000) + 500);
		} catch (RuntimeException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
