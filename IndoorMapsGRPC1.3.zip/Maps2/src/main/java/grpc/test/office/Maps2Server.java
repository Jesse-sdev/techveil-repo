
package grpc.test.office;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

import grpc.test.office.InputRequest.Selection;
import grpc.test.office.indoormapsGrpc.indoormapsImplBase;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class Maps2Server extends indoormapsImplBase {
	// logger helps in tracing errors by storing info about created methods into a
	// log. Also used to print out.
	private static final Logger logger = Logger.getLogger(Maps2Server.class.getName());

	public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("Starting Server...");
		// creating a new instance of the service to be used
		Maps2Server mapsServer = new Maps2Server();
		
		//to obtain naming properties
		Properties prop= mapsServer.getProperties();
		
		//register the service
		mapsServer.registerService(prop);
		
		// initializing the port to be listened to
		int port = Integer.valueOf( prop.getProperty("service_port"));

		// use try to create the server...
		try {
			// creating a server builder for the server
			Server server = ServerBuilder.forPort(port)
					// registering the service
					.addService(mapsServer)
					// finally build
					.build()
					// then you can call start to begin listening on port
					.start();

			// to prevent main process from quitting by itself after running in background
			server.awaitTermination();

			// ..and catch to capture possible errors
		} catch (IOException e) {
			e.printStackTrace();

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		logger.info("Server started, listening on " + port);
	}

	
	//method to obtain listed properties in .properties file
	private Properties getProperties() {
		Properties prop = null;		
		
		 try (InputStream input = new FileInputStream("src/main/resources/maps2.properties")) {

	            prop = new Properties();

	            // load a properties file
	            prop.load(input);

	            // get the property value and print it out
	            System.out.println("Indoor Maps Service properties ...");
	            System.out.println("\t service_type: " + prop.getProperty("service_type"));
	            System.out.println("\t service_name: " +prop.getProperty("service_name"));
	            System.out.println("\t service_description: " +prop.getProperty("service_description"));
		        System.out.println("\t service_port: " +prop.getProperty("service_port"));

	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }
	
		 return prop;
	}
	
	//method to register service with listed properties
	private void registerService(Properties prop) {
		 try {
	            // Create a JmDNS instance
	            JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());
	            
	         // Retrieving and storing the property components in variables
	            String service_type = prop.getProperty("service_type") ;
	            String service_name = prop.getProperty("service_name")  ;
	            int service_port = Integer.valueOf( prop.getProperty("service_port"));	            
	            String service_description_properties = prop.getProperty("service_description");
	            
	            // Register service
	            ServiceInfo serviceInfo = ServiceInfo.create(service_type, service_name, service_port, service_description_properties);
	            jmdns.registerService(serviceInfo);
	            
	            System.out.printf("Registering service with type %s and name %s \n", service_type, service_name);
	            
	            // Wait a bit
	            Thread.sleep(1000);

	            // Unregister all services
	            //jmdns.unregisterAllServices();

	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	            
	        } catch (InterruptedException e) {
				e.printStackTrace();
			}
		
	}

	

	// this is the overridden server stub for bidirectional service of streamLocation
	@Override
	public StreamObserver<InputRequest> streamLocation(StreamObserver<OutputReply> responseObserver) {
		return new StreamObserver<InputRequest>() {

			@Override
			public void onNext(InputRequest request) {				
				
				String occupied = request.getOccupied();			
				Selection room= request.getSelection();
				String usage= "";
				String duration= "";

				// to generate random time to assign to rooms
				int timer = 0;
				Random rand = new Random();
				timer = rand.nextInt(120);

				System.out.println("Office room selected : " + room + ", Is occupied? : " + occupied + "\n");	
				
				//conditions for output to client
				if((room==Selection.Conference1||room==Selection.Conference2||room== Selection.Recreation) && occupied.equals("yes")) {
					usage= "Selected room is occupied!";
					duration= "\nTime left: " + timer + " minutes";
				}else if((room==Selection.Conference1||room==Selection.Conference2||room== Selection.Recreation) && occupied.equals("no")) {
					usage= "A maximum of 15 persons is allowed in the room at the time!";
							duration= "\nRoom available for maximum of 120 minutes";
				}else {
					usage= "This room: "+ room + ", cannot be selected!";
					duration= "\nNo time allocated for this room!";
				}
					

				// gets reply back to client. onNext sends one set of data from server to client
				// after another
				OutputReply reply = OutputReply.newBuilder().setOccupancy(usage).setDuration(duration).build();
				responseObserver.onNext(reply);

			}

			@Override
			public void onError(Throwable t) {
				t.printStackTrace();

			}

			@Override
			public void onCompleted() {
				System.out.println("========================================");
				responseObserver.onCompleted();

			}

		};
	}
}

