package grpc.test.office;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

//java class to implement temperature regulator client service 
public class TempRegGUI implements ActionListener {

	private static final Logger logger = Logger.getLogger(TempRegulatorClient.class.getName());

	private static TempRegulatorGrpc.TempRegulatorBlockingStub blockingStub;
	private static TempRegulatorGrpc.TempRegulatorStub asyncStub;

	// declaring variable to store serviceInfo object
	private ServiceInfo tregServiceInfo;

	// variables used in GUi frame and component setup
	JLabel header;
	JLabel header2;
	JLabel roomlabel;
	JLabel currentTemp;
	JLabel templabel;
	JFrame frame;
	JPanel panel;
	JButton button;
	static JTextField roomText;
	static JTextField tempText;
	static JLabel message1;
	static JLabel message2;
	static JLabel message3;
	
	static JTextArea txtarea;

	// implementing GUI properties in constructor
	public TempRegGUI() {
		TempRegulatorServer tregserver = new TempRegulatorServer();
		String treg_service_type = "_treg._tcp.local.";
		discoverTempRegService(treg_service_type);

		frame = new JFrame();

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(40, 40, 10, 40));
		panel.setLayout(new BorderLayout(20, 40));

		ImageIcon image = new ImageIcon("C:\\Users\\chigb\\Desktop\\logos.png");

		// frame.getContentPane().add(panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 600, 450);
		frame.setMinimumSize(new Dimension(600, 550));
		frame.setTitle("Indoor Thermostat");
		frame.setIconImage(image.getImage());
		frame.pack();
		frame.setVisible(true);

		JScrollPane sbar = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.add(sbar);
		frame.setLocationRelativeTo(null);

		header = new JLabel("Welcome To BlueLights! ", JLabel.CENTER);
		header.setBounds(50, 10, 280, 25);
		header.setPreferredSize(new Dimension(280, 80));
		header.setFont(new Font("Serif", Font.ITALIC | Font.ITALIC, 25));
		header.setForeground(Color.BLUE);
		panel.add(header);

		header2 = new JLabel("Please be considerate when changing temperature of any room. Thank you!", JLabel.LEFT);
		header2.setBounds(20, 40, 680, 25);
		header2.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		header2.setForeground(Color.RED);
		panel.add(header2);

		roomlabel = new JLabel("ROOM: ");
		roomlabel.setBounds(5, 75, 100, 25);
		panel.add(roomlabel);

		roomText = new JTextField();
		roomText.setBounds(280, 75, 150, 25);
		panel.add(roomText);

		templabel = new JLabel("SET TEMPERATURE(degrees Celcius): ");
		templabel.setBounds(5, 150, 260, 25);
		panel.add(templabel);

		tempText = new JTextField();
		tempText.setBounds(280, 150, 150, 25);
		panel.add(tempText);

		button = new JButton("Ok");
		button.setBounds(5, 205, 100, 25);
		button.addActionListener(this); // calling action performed on the constructor of this class
		panel.add(button);

		message1 = new JLabel("");
		message1.setBounds(10, 225, 600, 155);
		message1.setFont(new Font("Verdana", Font.BOLD, 14));
		message1.setForeground(Color.BLUE);
		panel.add(message1);

		message2 = new JLabel("");
		message2.setBounds(10, 265, 800, 155);
		panel.add(message2);

		message3 = new JLabel("");
		message3.setBounds(10, 295, 500, 155);
		panel.add(message3);

		txtarea = new JTextArea(7, 35);
		txtarea.setLineWrap(true);
		txtarea.setWrapStyleWord(true);
		txtarea.setEditable(false);
		txtarea.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 14));

		JScrollPane scrollPane = new JScrollPane(txtarea);
		panel.add(scrollPane, BorderLayout.SOUTH);
		
	}

	private void discoverTempRegService(String service_type) {

		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			jmdns.addServiceListener(service_type, new ServiceListener() {

				@Override
				// for resolving service
				public void serviceResolved(ServiceEvent event) {
					System.out.println("TempRegulator Service resolved: " + event.getInfo());

					tregServiceInfo = event.getInfo();

					int port = tregServiceInfo.getPort();

					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port);
					System.out.println("\t type:" + event.getType());
					System.out.println("\t name: " + event.getName());
					System.out.println("\t description/properties: " + tregServiceInfo.getNiceTextString());
					System.out.println("\t host: " + tregServiceInfo.getHostAddresses()[0]);

				}

				@Override
				// for removing service
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("TempRegulator Service removed: " + event.getInfo());

				}

				@Override
				// for adding service
				public void serviceAdded(ServiceEvent event) {
					System.out.println("TempRegulator Service added: " + event.getInfo());

				}

			});

			// Wait a bit
			Thread.sleep(2000);

			jmdns.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// main method
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// calls the constructor which contains actionable code
					new TempRegGUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// with this method, the main functionality of the client as well ass the naming
	// service is initialized
	public void actionPerformed(ActionEvent e) {

		String host = "localhost";
		int port = 50051;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing async stub for stream services and blocking for unary
		blockingStub = TempRegulatorGrpc.newBlockingStub(channel);
		asyncStub = TempRegulatorGrpc.newStub(channel);

		// calling method for server streaming
		tempAsync();

		// shutdown channel
		try {
			channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
		} catch (InterruptedException i) {
			// TODO Auto-generated catch block
			i.printStackTrace();
		}
	}

	// server-side streaming service with async stub
	public static void tempAsync() {

		String room = roomText.getText();
		String temp = tempText.getText();

		// random temperature range between 16-30 degrees Celcius to serve as current
		// temperature of room.
		int xTemp = (int) Math.floor(Math.random() * (30 - 16 + 1) + 16);
		System.out.println("Current Temperature:: " + xTemp + " degrees");

		TempRequest request = TempRequest.newBuilder().setLocation(room).setDTemp(Integer.parseInt(temp))
				.setXTemp(xTemp).build();

		// client server creation..
		StreamObserver<ControlResponse> responseObserver = new StreamObserver<ControlResponse>() {

			@Override
			public void onNext(ControlResponse response) {
				// print out to terminal
				System.out.println("Temperature regulator:: " + response);

				// print out to GUI client
				message1.setText("Current Temperature:: " + xTemp + " degrees");
				//message2.setText("\nTemperature regulator:: " + response.getRegulator());
				//message3.setText("\n New Temperature: " + response.getNewTemp() + " degrees.");

				txtarea.append("Temperature regulator:: " + response + "\n");
			}

			@Override
			public void onError(Throwable t) {
				t.printStackTrace();
			}

			@Override
			public void onCompleted() {
				System.out.println("......Temp Regulator server completed......");
				System.out.println("====================================");
			}

		};

		asyncStub.tempReg(request, responseObserver);

		try {

			// Sleep for a bit before sending the next one.
			Thread.sleep(10000);

		} catch (RuntimeException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
