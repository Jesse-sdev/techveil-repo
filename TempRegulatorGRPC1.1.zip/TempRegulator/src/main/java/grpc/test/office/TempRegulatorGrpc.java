package grpc.test.office;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 * This service is used to control the atmosphere with regards to temperature preference within various rooms/offices.
 *it requires a manual setting of desired temperature and the return from the server as to the completion of making changes to temperature.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: TempReg.proto")
public final class TempRegulatorGrpc {

  private TempRegulatorGrpc() {}

  public static final String SERVICE_NAME = "office.TempRegulator";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<grpc.test.office.TempRequest,
      grpc.test.office.ControlResponse> getTempRegMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "tempReg",
      requestType = grpc.test.office.TempRequest.class,
      responseType = grpc.test.office.ControlResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<grpc.test.office.TempRequest,
      grpc.test.office.ControlResponse> getTempRegMethod() {
    io.grpc.MethodDescriptor<grpc.test.office.TempRequest, grpc.test.office.ControlResponse> getTempRegMethod;
    if ((getTempRegMethod = TempRegulatorGrpc.getTempRegMethod) == null) {
      synchronized (TempRegulatorGrpc.class) {
        if ((getTempRegMethod = TempRegulatorGrpc.getTempRegMethod) == null) {
          TempRegulatorGrpc.getTempRegMethod = getTempRegMethod = 
              io.grpc.MethodDescriptor.<grpc.test.office.TempRequest, grpc.test.office.ControlResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "office.TempRegulator", "tempReg"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.test.office.TempRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.test.office.ControlResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new TempRegulatorMethodDescriptorSupplier("tempReg"))
                  .build();
          }
        }
     }
     return getTempRegMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static TempRegulatorStub newStub(io.grpc.Channel channel) {
    return new TempRegulatorStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static TempRegulatorBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new TempRegulatorBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static TempRegulatorFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new TempRegulatorFutureStub(channel);
  }

  /**
   * <pre>
   * This service is used to control the atmosphere with regards to temperature preference within various rooms/offices.
   *it requires a manual setting of desired temperature and the return from the server as to the completion of making changes to temperature.
   * </pre>
   */
  public static abstract class TempRegulatorImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Provides temperature control and response to temperature changes
     * </pre>
     */
    public void tempReg(grpc.test.office.TempRequest request,
        io.grpc.stub.StreamObserver<grpc.test.office.ControlResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getTempRegMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getTempRegMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                grpc.test.office.TempRequest,
                grpc.test.office.ControlResponse>(
                  this, METHODID_TEMP_REG)))
          .build();
    }
  }

  /**
   * <pre>
   * This service is used to control the atmosphere with regards to temperature preference within various rooms/offices.
   *it requires a manual setting of desired temperature and the return from the server as to the completion of making changes to temperature.
   * </pre>
   */
  public static final class TempRegulatorStub extends io.grpc.stub.AbstractStub<TempRegulatorStub> {
    private TempRegulatorStub(io.grpc.Channel channel) {
      super(channel);
    }

    private TempRegulatorStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TempRegulatorStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new TempRegulatorStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provides temperature control and response to temperature changes
     * </pre>
     */
    public void tempReg(grpc.test.office.TempRequest request,
        io.grpc.stub.StreamObserver<grpc.test.office.ControlResponse> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getTempRegMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * This service is used to control the atmosphere with regards to temperature preference within various rooms/offices.
   *it requires a manual setting of desired temperature and the return from the server as to the completion of making changes to temperature.
   * </pre>
   */
  public static final class TempRegulatorBlockingStub extends io.grpc.stub.AbstractStub<TempRegulatorBlockingStub> {
    private TempRegulatorBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private TempRegulatorBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TempRegulatorBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new TempRegulatorBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provides temperature control and response to temperature changes
     * </pre>
     */
    public java.util.Iterator<grpc.test.office.ControlResponse> tempReg(
        grpc.test.office.TempRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getTempRegMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * This service is used to control the atmosphere with regards to temperature preference within various rooms/offices.
   *it requires a manual setting of desired temperature and the return from the server as to the completion of making changes to temperature.
   * </pre>
   */
  public static final class TempRegulatorFutureStub extends io.grpc.stub.AbstractStub<TempRegulatorFutureStub> {
    private TempRegulatorFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private TempRegulatorFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TempRegulatorFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new TempRegulatorFutureStub(channel, callOptions);
    }
  }

  private static final int METHODID_TEMP_REG = 0;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final TempRegulatorImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(TempRegulatorImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_TEMP_REG:
          serviceImpl.tempReg((grpc.test.office.TempRequest) request,
              (io.grpc.stub.StreamObserver<grpc.test.office.ControlResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class TempRegulatorBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    TempRegulatorBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return grpc.test.office.OfficeServiceImpl.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("TempRegulator");
    }
  }

  private static final class TempRegulatorFileDescriptorSupplier
      extends TempRegulatorBaseDescriptorSupplier {
    TempRegulatorFileDescriptorSupplier() {}
  }

  private static final class TempRegulatorMethodDescriptorSupplier
      extends TempRegulatorBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    TempRegulatorMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (TempRegulatorGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new TempRegulatorFileDescriptorSupplier())
              .addMethod(getTempRegMethod())
              .build();
        }
      }
    }
    return result;
  }
}
