package grpc.test.office;

import java.util.Iterator;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

public class TempRegulatorClient {

	private static final Logger logger = Logger.getLogger(TempRegulatorClient.class.getName());

	//static stubs to be able to access them within the java class
	private static TempRegulatorGrpc.TempRegulatorBlockingStub blockingStub;
	private static TempRegulatorGrpc.TempRegulatorStub asyncStub;

	public static void main(String[] args) throws Exception {
		String host = "localhost";
		int port = 50051;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing to use blocking stub which blocks code till data is returned from
		// server
		blockingStub = TempRegulatorGrpc.newBlockingStub(channel);
		asyncStub = TempRegulatorGrpc.newStub(channel);

		//calling server-side tempAsync method
		tempAsync();
	}

	public static void tempBlocking() {
		//random temperature range between 16-30 degrees Celcius to serve as current temperature of room.
				int xTemp = (int) Math.floor(Math.random() * (30 - 16 + 1) + 16);
				System.out.println("Current Temperature:: " + xTemp + " degrees");
		TempRequest request = TempRequest.newBuilder().setLocation("conference1").setDTemp(22).setXTemp(xTemp).build();
	
		try {
			Iterator<ControlResponse> response = blockingStub.tempReg(request); 
			while (response.hasNext()) {
				ControlResponse temp = response.next();
				System.out.println("Temperature regulator:: " + temp);
	
			}
			
		} catch (StatusRuntimeException e) {
			e.printStackTrace();
		}
	}
	
	//method for server-side streaming 
	public static void tempAsync() {
		//random temperature range between 16-30 degrees Celcius to serve as current temperature of room.
		int xTemp = (int) Math.floor(Math.random() * (30 - 16 + 1) + 16);
		
		System.out.println("Current Temperature:: " + xTemp + " degrees");
		
		TempRequest request = TempRequest.newBuilder().setLocation("conference1").setDTemp(22).setXTemp(xTemp).build();
		
		// client server creation..
		StreamObserver<ControlResponse> responseObserver = new StreamObserver<ControlResponse>() {

			@Override
			public void onNext(ControlResponse response) {

				System.out.println("Temperature regulator:: " + response);
		
			}

			@Override
			public void onError(Throwable t) {
				t.printStackTrace();

			}

			@Override
			public void onCompleted() {
				System.out.println("......server completed......");
			}

		};

		//using async stub to call response from server side 
		asyncStub.tempReg(request, responseObserver);

		try {

			// Sleep for a bit before sending the next one.
			Thread.sleep(80000);

		} catch (RuntimeException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
