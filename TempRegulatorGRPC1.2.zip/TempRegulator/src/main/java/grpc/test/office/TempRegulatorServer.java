package grpc.test.office;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.Properties;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

import grpc.test.office.TempRegulatorGrpc.TempRegulatorImplBase;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class TempRegulatorServer extends TempRegulatorImplBase {

	// logger helps in tracing errors by storing info about created methods into a
	// log.
	private static final Logger logger = Logger.getLogger(TempRegulatorServer.class.getName());

	public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("Starting Server...");
		// creating a new instance of the service to be used
		TempRegulatorServer tregserver = new TempRegulatorServer();

		// to obtain naming properties
		Properties prop = tregserver.getProperties();
		// register the service
		tregserver.registerService(prop);

		// initializing the port to be listened to
		int port = 50051;

		// use try to create the server...
		try {
			// creating a server builder for the server
			Server server = ServerBuilder.forPort(port)
					// registering the service
					.addService(tregserver)
					// finally build
					.build()
					// then you can call start to begin listening on port
					.start();

			// to prevent main process from quitting by itself after running in background
			server.awaitTermination();

			// ..and catch to capture possible errors
		} catch (IOException e) {
			e.printStackTrace();

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		logger.info("Server started, listening on " + port);

	}

	// method to obtain listed properties in .properties file
	private Properties getProperties() {
		Properties prop = null;

		try (InputStream input = new FileInputStream("src/main/resources/tempreg.properties")) {

			prop = new Properties();

			// load a properties file
			prop.load(input);

			// get the property value and print it out
			System.out.println("Temperature Regulator Service properties ...");
			System.out.println("\t service_type: " + prop.getProperty("service_type"));
			System.out.println("\t service_name: " + prop.getProperty("service_name"));
			System.out.println("\t service_description: " + prop.getProperty("service_description"));
			System.out.println("\t service_port: " + prop.getProperty("service_port"));

		} catch (IOException ex) {
			ex.printStackTrace();
		}

		return prop;
	}

	// method to register service with listed properties
	private void registerService(Properties prop) {
		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			String service_type = prop.getProperty("service_type");
			String service_name = prop.getProperty("service_name");
			int service_port = Integer.valueOf(prop.getProperty("service_port"));
			String service_description_properties = prop.getProperty("service_description");
			
			// Register a service
			ServiceInfo serviceInfo = ServiceInfo.create(service_type, service_name, service_port,
					service_description_properties);
			jmdns.registerService(serviceInfo);

			System.out.printf("Registering service with type %s and name %s \n", service_type, service_name);

			// Wait a bit
			Thread.sleep(1000);

			// Unregister all services
			// jmdns.unregisterAllServices();

		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	@Override
	// default async operation on server side
	public void tempReg(TempRequest request, StreamObserver<ControlResponse> responseObserver) {
		// using variables to store values from client
		String location = request.getLocation(); // location in office
		int DTemp = request.getDTemp(); // Desired temperature
		int xTemp = request.getXTemp(); // generated current temperature

		System.out.println("===================================================");
		System.out.println("Current Temperature:: " + xTemp + " degrees");
		int count = 1;

		// System.out.println("Receiving Desired Temperature for : "+ location);
		
		// initialising ControlResponse and building
		//ControlResponse.Builder reply = ControlResponse.newBuilder();

		System.out.println("Location : " + location + ", Desired Temperature(degrees):  " + DTemp + "\n");

		if ((location.equalsIgnoreCase("conference1") || location.equalsIgnoreCase("conference2")
				|| location.equalsIgnoreCase("recreation")) && xTemp > DTemp) {
			while (xTemp != DTemp) {
				responseObserver.onNext(ControlResponse.newBuilder().setRegulator("Decreasing temperature by: " + count + " degrees").setNewTemp(xTemp-1).build());
				xTemp--;
				count++;
			}
			//responseObserver.onNext(ControlResponse.newBuilder().setRegulator("Decreasing temperature by: " + (count+1) + " degrees").setNewTemp(xTemp-1).build());
			//responseObserver.onNext(ControlResponse.newBuilder().setRegulator("Decreasing temperature by: " + count + " degrees").setNewTemp(xTemp).build());
			
		} else if ((location.equalsIgnoreCase("conference1") || location.equalsIgnoreCase("conference2")
				|| location.equalsIgnoreCase("recreation")) && xTemp < DTemp) {
			while (xTemp != DTemp) {
				responseObserver.onNext(ControlResponse.newBuilder().setRegulator("Increasing temperature by: " + count + " degrees").setNewTemp(xTemp+1).build());
				xTemp++;
				count++;
			}
			//responseObserver.onNext(ControlResponse.newBuilder().setRegulator("Increasing temperature by: " + count + " degrees").setNewTemp(xTemp).build());

		} else {
			responseObserver.onNext(ControlResponse.newBuilder().setRegulator("Temperature can not be regulated or the room selected cannot be altered, try Conference1/ Conference2/ Recreation)").setNewTemp(0).build());

		}


		// onCompleted used to finish the responses.
		responseObserver.onCompleted();
	}

}
