package grpc.test.office;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import grpc.test.office.UniqueAccessCodeGrpc.UniqueAccessCodeBlockingStub;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class AccessGUI implements ActionListener {

	// declaring variable to store serviceInfo object
	private ServiceInfo accesscodeServiceInfo;

	// variables used in GUi frame and component setup
	JLabel header;
	JLabel userlabel;
	JLabel pwlabel;
	JFrame frame;
	JPanel panel;
	JButton button;
	JTextField userText;
	JPasswordField pwText;
	JLabel access;

	// implementing GUI properties in constructor
	public AccessGUI() {

		// calling discovery method
		String uac_service_type = "_accesscode._tcp.local.";
		discoverUACService(uac_service_type);

		frame = new JFrame();

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(40, 40, 10, 40));
		panel.setLayout(null);

		ImageIcon image = new ImageIcon("C:\\Users\\chigb\\Desktop\\logos.png");

		// frame.getContentPane().add(panel, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 600, 450);
		frame.setMinimumSize(new Dimension(600, 400));
		frame.setTitle("Staff Login");
		frame.setIconImage(image.getImage());
		frame.pack();
		frame.setVisible(true);

		JScrollPane sbar = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.add(sbar);
		frame.setLocationRelativeTo(null);

		header = new JLabel("Welcome To BlueLights! ", JLabel.CENTER);
		header.setBounds(50, 10, 280, 25);
		header.setPreferredSize(new Dimension(100, 80));
		header.setFont(new Font("Serif", Font.ITALIC | Font.ITALIC, 25));
		header.setForeground(Color.BLUE);
		panel.add(header);

		userlabel = new JLabel("UserName: ");
		userlabel.setBounds(5, 85, 80, 25);
		panel.add(userlabel);

		userText = new JTextField();
		userText.setBounds(80, 85, 165, 25);
		panel.add(userText);

		pwlabel = new JLabel("ID: ");
		pwlabel.setBounds(5, 125, 80, 25);
		panel.add(pwlabel);

		pwText = new JPasswordField();
		pwText.setBounds(80, 125, 165, 25);
		panel.add(pwText);

		button = new JButton("Login");
		button.setBounds(80, 160, 80, 25);
		button.addActionListener(this);
		panel.add(button);

		access = new JLabel("");
		access.setBounds(10, 220, 800, 25);
		access.setFont(new Font("Verdana", Font.BOLD, 13));
		access.setForeground(Color.BLUE);
		panel.add(access);
		
	}

	// grpc service discovery by naming service
	private void discoverUACService(String service_type) {

		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

			jmdns.addServiceListener(service_type, new ServiceListener() {

				@Override
				// for resolving service
				public void serviceResolved(ServiceEvent event) {
					System.out.println("UniqueAccessCode Service resolved: " + event.getInfo());

					accesscodeServiceInfo = event.getInfo();

					int port = accesscodeServiceInfo.getPort();

					System.out.println("resolving " + service_type + " with properties ...");
					System.out.println("\t port: " + port);
					System.out.println("\t type:" + event.getType());
					System.out.println("\t name: " + event.getName());
					System.out.println("\t description/properties: " + accesscodeServiceInfo.getNiceTextString());
					System.out.println("\t host: " + accesscodeServiceInfo.getHostAddresses()[0]);

				}

				@Override
				// for removing service
				public void serviceRemoved(ServiceEvent event) {
					System.out.println("UniqueAccessCode Service removed: " + event.getInfo());

				}

				@Override
				// for adding service
				public void serviceAdded(ServiceEvent event) {
					System.out.println("UniqueAccessCode Service added: " + event.getInfo());

				}
			});

			// Wait a bit
			Thread.sleep(2000);

			jmdns.close();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// main method to execute entire program
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// calls the constructor which contains actionable code
					new AccessGUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// with this method, the main functionality of the client as well ass the naming
	// service is initialised
	public void actionPerformed(ActionEvent arg0) {

		String host = "localhost";
		int port = 50055;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();
		UniqueAccessCodeBlockingStub blockingStub = UniqueAccessCodeGrpc.newBlockingStub(channel);

		// obtaining input from GUI and storing it in variables
		String username = userText.getText();
		String id = pwText.getText();
		// assigning a variable "request" to the building of HelloRequest from the
		// client
		InputRequest request = InputRequest.newBuilder().setId(id).setName(username).build();

		// using the stub selected, derive a response from the server based on the
		// request passed in.
		AccessReply response = blockingStub.provideCode(request);

		System.out.println("===========================================");
		// print out to IDE
		System.out.println("Response from Server: " + response.getMessage());

		// print to GUI
		access.setText("Response from server: " + response.getMessage());
		

	}

}
