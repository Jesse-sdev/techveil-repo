package grpc.test.office;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 * The Unique Access service definition.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: uniqueAC.proto")
public final class UniqueAccessCodeGrpc {

  private UniqueAccessCodeGrpc() {}

  public static final String SERVICE_NAME = "office.UniqueAccessCode";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<grpc.test.office.InputRequest,
      grpc.test.office.AccessReply> getProvideCodeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ProvideCode",
      requestType = grpc.test.office.InputRequest.class,
      responseType = grpc.test.office.AccessReply.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.test.office.InputRequest,
      grpc.test.office.AccessReply> getProvideCodeMethod() {
    io.grpc.MethodDescriptor<grpc.test.office.InputRequest, grpc.test.office.AccessReply> getProvideCodeMethod;
    if ((getProvideCodeMethod = UniqueAccessCodeGrpc.getProvideCodeMethod) == null) {
      synchronized (UniqueAccessCodeGrpc.class) {
        if ((getProvideCodeMethod = UniqueAccessCodeGrpc.getProvideCodeMethod) == null) {
          UniqueAccessCodeGrpc.getProvideCodeMethod = getProvideCodeMethod = 
              io.grpc.MethodDescriptor.<grpc.test.office.InputRequest, grpc.test.office.AccessReply>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "office.UniqueAccessCode", "ProvideCode"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.test.office.InputRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.test.office.AccessReply.getDefaultInstance()))
                  .setSchemaDescriptor(new UniqueAccessCodeMethodDescriptorSupplier("ProvideCode"))
                  .build();
          }
        }
     }
     return getProvideCodeMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static UniqueAccessCodeStub newStub(io.grpc.Channel channel) {
    return new UniqueAccessCodeStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static UniqueAccessCodeBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new UniqueAccessCodeBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static UniqueAccessCodeFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new UniqueAccessCodeFutureStub(channel);
  }

  /**
   * <pre>
   * The Unique Access service definition.
   * </pre>
   */
  public static abstract class UniqueAccessCodeImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Provide permission to acces building
     * </pre>
     */
    public void provideCode(grpc.test.office.InputRequest request,
        io.grpc.stub.StreamObserver<grpc.test.office.AccessReply> responseObserver) {
      asyncUnimplementedUnaryCall(getProvideCodeMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getProvideCodeMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.test.office.InputRequest,
                grpc.test.office.AccessReply>(
                  this, METHODID_PROVIDE_CODE)))
          .build();
    }
  }

  /**
   * <pre>
   * The Unique Access service definition.
   * </pre>
   */
  public static final class UniqueAccessCodeStub extends io.grpc.stub.AbstractStub<UniqueAccessCodeStub> {
    private UniqueAccessCodeStub(io.grpc.Channel channel) {
      super(channel);
    }

    private UniqueAccessCodeStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UniqueAccessCodeStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new UniqueAccessCodeStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide permission to acces building
     * </pre>
     */
    public void provideCode(grpc.test.office.InputRequest request,
        io.grpc.stub.StreamObserver<grpc.test.office.AccessReply> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getProvideCodeMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * The Unique Access service definition.
   * </pre>
   */
  public static final class UniqueAccessCodeBlockingStub extends io.grpc.stub.AbstractStub<UniqueAccessCodeBlockingStub> {
    private UniqueAccessCodeBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private UniqueAccessCodeBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UniqueAccessCodeBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new UniqueAccessCodeBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide permission to acces building
     * </pre>
     */
    public grpc.test.office.AccessReply provideCode(grpc.test.office.InputRequest request) {
      return blockingUnaryCall(
          getChannel(), getProvideCodeMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * The Unique Access service definition.
   * </pre>
   */
  public static final class UniqueAccessCodeFutureStub extends io.grpc.stub.AbstractStub<UniqueAccessCodeFutureStub> {
    private UniqueAccessCodeFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private UniqueAccessCodeFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UniqueAccessCodeFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new UniqueAccessCodeFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide permission to acces building
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.test.office.AccessReply> provideCode(
        grpc.test.office.InputRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getProvideCodeMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_PROVIDE_CODE = 0;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final UniqueAccessCodeImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(UniqueAccessCodeImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_PROVIDE_CODE:
          serviceImpl.provideCode((grpc.test.office.InputRequest) request,
              (io.grpc.stub.StreamObserver<grpc.test.office.AccessReply>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class UniqueAccessCodeBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    UniqueAccessCodeBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return grpc.test.office.OfficeServiceImpl.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("UniqueAccessCode");
    }
  }

  private static final class UniqueAccessCodeFileDescriptorSupplier
      extends UniqueAccessCodeBaseDescriptorSupplier {
    UniqueAccessCodeFileDescriptorSupplier() {}
  }

  private static final class UniqueAccessCodeMethodDescriptorSupplier
      extends UniqueAccessCodeBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    UniqueAccessCodeMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (UniqueAccessCodeGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new UniqueAccessCodeFileDescriptorSupplier())
              .addMethod(getProvideCodeMethod())
              .build();
        }
      }
    }
    return result;
  }
}
