package grpc.test.office;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import grpc.test.office.UniqueAccessCodeGrpc.UniqueAccessCodeBlockingStub;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

//client creates connection to server, calls server and gives it instructions. Which in return prints it out
public class UniqueACClient {

	private static final Logger logger = Logger.getLogger(UniqueACClient.class.getName());

	public static void main(String[] args) throws Exception {
		
		String host = "localhost";
		int port = 50055;

		// uses channel to run all behind the scenes operations with resolvers, IP
		// address and load-balancing
		ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

		// choosing to use blocking stub which blocks code till data is returned from
		// server
		UniqueAccessCodeBlockingStub blockingStub = UniqueAccessCodeGrpc.newBlockingStub(channel);

		// new instance of client class
		UniqueACClient client = new UniqueACClient();

		// client server creation..
		try {

			// assigning a variable "request" to the building of HelloRequest from the
			// client
			InputRequest request = InputRequest.newBuilder().setId("A2215").setName("Jesse").build();

			// using the stub selected, derive a response from the server based on the
			// request passed in.
			AccessReply response = blockingStub.provideCode(request);

			// print out with logger. can use system.out.print instead
			logger.info("Response from Server: " + response.getMessage());

			// catch all possible exceptions
		} catch (StatusRuntimeException e) {
			logger.log(Level.WARNING, "RPC failed: {0}", e.getStatus());

			return;

		} finally {
			// shutdown channel
			channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
		}
	}

}
